<?php
/**
 * Кастомный хедер Flag Center
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#fc-main">Перейти к содержимому</a>

<header class="fc-header" id="fc-header">

    <!-- ВЕРХНЯЯ ПОЛОСА -->
    <div class="fc-header__top">
        <div class="fc-container fc-header__top-inner">

            <div class="fc-header__top-left">
                <span class="fc-header__info">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    Новосибирск, ул. Мусы Джалиля, 21/5
                </span>
                <a class="fc-header__info" href="mailto:flagcenter@flagcenter.ru">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    flagcenter@flagcenter.ru
                </a>
            </div>

            <div class="fc-header__top-right">
                <a class="fc-header__phone" href="tel:+73833251222">
    +7 (383) 325-12-22
</a>
<a class="fc-header__phone" href="tel:+79137191188">
    +7 913 719-11-88
</a>
                </a>

                <div class="fc-header__socials">
                    <a href="https://t.me/+79137191188" target="_blank" rel="noopener" aria-label="Telegram">
                        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-telegram.webp' ); ?>" alt="Telegram" width="16" height="16">
                    </a>
                    <a href="https://max.ru/id5408257072_biz" target="_blank" rel="noopener" aria-label="MAX">
                        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-whatsapp.webp' ); ?>" alt="MAX" width="16" height="16">
                    </a>
                </div>

                <button type="button" class="fc-header__callback" data-fc-modal="callback">
                    Заказать звонок
                </button>
            </div>

        </div>
    </div>

    <!-- СРЕДНЯЯ ПОЛОСА -->
    <div class="fc-header__main">
        <div class="fc-container fc-header__main-inner">

            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="fc-header__logo">
                <?php if ( has_custom_logo() ) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/logo.svg' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
                <?php endif; ?>
            </a>

            <div class="fc-header__catalog-wrap">
    <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="fc-header__catalog-btn">
        <span class="fc-burger"><span></span><span></span><span></span></span>
        Каталог
    </a>

    <div class="fc-catalog-dropdown">
        <ul class="fc-catalog-dropdown__list">
            <?php
            $categories = get_terms([
                'taxonomy'   => 'product_cat',
                'hide_empty' => false,
                'parent'     => 0,
                'orderby'    => 'menu_order',
                'order'      => 'ASC',
            ]);

            if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) :
                foreach ( $categories as $cat ) :
                    $children = get_terms([
                        'taxonomy'   => 'product_cat',
                        'hide_empty' => false,
                        'parent'     => $cat->term_id,
                    ]);
                    $has_children = ! empty( $children ) && ! is_wp_error( $children );
                    ?>
                    <li class="fc-catalog-dropdown__item <?php echo $has_children ? 'has-children' : ''; ?>">
                        <a href="<?php echo esc_url( get_term_link( $cat ) ); ?>">
                            <?php echo esc_html( $cat->name ); ?>
                            <?php if ( $has_children ) : ?>
                                <span class="fc-catalog-dropdown__arrow">›</span>
                            <?php endif; ?>
                        </a>

                        <?php if ( $has_children ) : ?>
                            <ul class="fc-catalog-dropdown__sub">
                                <?php foreach ( $children as $child ) : ?>
                                    <li>
                                        <a href="<?php echo esc_url( get_term_link( $child ) ); ?>">
                                            <?php echo esc_html( $child->name ); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach;
            else : ?>
                <li><a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>">Все товары</a></li>
            <?php endif; ?>
        </ul>
    </div>
</div>

            <form class="fc-header__search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <input type="search" name="s" placeholder="Поиск по сайту" value="<?php echo get_search_query(); ?>">
                <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                    <input type="hidden" name="post_type" value="product">
                <?php endif; ?>
            </form>

            <div class="fc-header__actions">
                <a href="<?php echo esc_url( get_permalink( get_option( 'woocommerce_myaccount_page_id' ) ) ); ?>" class="fc-header__icon" aria-label="Личный кабинет">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                </a>
                <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="fc-header__icon fc-header__cart" aria-label="Корзина">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>
                    <span class="fc-header__cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                </a>
            </div>

            <button type="button" class="fc-header__burger" id="fc-mobile-toggle" aria-label="Меню">
                <span></span><span></span><span></span>
            </button>

        </div>
    </div>

    <!-- НИЖНЯЯ ПОЛОСА — МЕНЮ -->
    <nav class="fc-header__nav" aria-label="Главное меню">
        <div class="fc-container">
            <?php
            wp_nav_menu([
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'fc-menu',
                'fallback_cb'    => false,
                'depth'          => 2,
            ]);
            ?>
        </div>
    </nav>

</header>

<!-- Мобильное меню -->
<div class="fc-mobile-menu" id="fc-mobile-menu">
    <div class="fc-mobile-menu__inner">
        <button type="button" class="fc-mobile-menu__close" id="fc-mobile-close" aria-label="Закрыть">×</button>

        <!-- Каталог -->
        <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="fc-mobile-menu__catalog">
            <span class="fc-burger"><span></span><span></span><span></span></span>
            Каталог
        </a>

        <!-- Поиск -->
        <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="fc-mobile-menu__search">
            <input type="search" name="s" placeholder="Поиск по сайту" value="<?php echo get_search_query(); ?>">
            <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                <input type="hidden" name="post_type" value="product">
            <?php endif; ?>
        </form>

        <!-- Меню -->
        <?php
        wp_nav_menu([
            'theme_location' => 'primary',
            'container'      => false,
            'menu_class'     => 'fc-mobile-menu__list',
            'fallback_cb'    => false,
        ]);
        ?>

        <!-- Контакты -->
        <div class="fc-mobile-menu__contacts">
            <a href="tel:+73833251222">+7 (383) 325-12-22</a>
            <a href="tel:+79137191188">+7 913 719-11-88</a>
            <a href="mailto:flagcenter@flagcenter.ru">flagcenter@flagcenter.ru</a>
        </div>

        <!-- Мессенджеры -->
        <div class="fc-mobile-menu__socials">
            <a href="https://t.me/flagcenter" target="_blank" rel="noopener" aria-label="Telegram">
            <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-telegram.webp' ); ?>" alt="Telegram" width="16" height="16">
            </a>
            <a href="https://max.ru/id5408257072_biz/" target="_blank" rel="noopener" aria-label="MAX">
                 <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-whatsapp.webp' ); ?>" alt="MAX" width="16" height="16">
            </a>
        </div>
    </div>
</div>