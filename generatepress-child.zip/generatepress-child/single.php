<?php
/**
 * Шаблон одной записи блога
 *
 * @package GeneratePress Child
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
?>

<main id="fc-main" class="fc-single">

    <div class="fc-container fc-container--narrow">

        <?php while ( have_posts() ) : the_post(); ?>

            <article class="fc-single-post">

                <!-- Заголовок -->
                <h1 class="fc-single-post__title"><?php the_title(); ?></h1>

                <!-- Дата -->
                <div class="fc-single-post__meta">
                    <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
                        <?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?>
                    </time>
                </div>

                <!-- Превью -->
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="fc-single-post__thumbnail">
                        <?php the_post_thumbnail( 'large' ); ?>
                    </div>
                <?php endif; ?>

                <!-- Контент -->
                <div class="fc-single-post__content">
                    <?php the_content(); ?>
                </div>

                <!-- Кнопка "Назад" -->
                <div class="fc-single-post__back">
                    <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="fc-btn fc-btn--outline">
                        ← Все статьи
                    </a>
                </div>

            </article>

        <?php endwhile; ?>

    </div>

</main>

<?php get_footer(); ?>