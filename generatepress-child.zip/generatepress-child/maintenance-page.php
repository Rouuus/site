<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сайт на техническом обслуживании</title>
    <style>
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background-color: #0A2A5E; /* Ваш фирменный синий */
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
            padding: 20px;
            box-sizing: border-box;
        }
        .container {
            max-width: 600px;
        }
        h1 {
            font-family: 'Manrope', sans-serif;
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #ffffff;
        }
        p {
            font-size: 1.1rem;
            line-height: 1.6;
            color: rgba(255,255,255,0.9);
            margin-bottom: 30px;
        }
        .logo {
            max-width: 180px;
            margin-bottom: 30px;
        }
        .contact-info {
            margin-top: 40px;
            font-size: 0.95rem;
            color: rgba(255,255,255,0.7);
            border-top: 1px solid rgba(255,255,255,0.2);
            padding-top: 20px;
        }
        .contact-info a {
            color: #E63946; /* Ваш фирменный красный */
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Замените путь на ваш логотип, если он есть -->
        <img src="/wp-content/themes/generatepress-child/images/logo.webp" alt="Флаг Центр" class="logo">
        
        <h1>Мы скоро вернёмся!</h1>
        <p>Наш сайт сейчас обновляется и совсем скоро снова будет доступен. Приносим извинения за временные неудобства.</p>
        
        <div class="contact-info">
            <p>Срочные вопросы можно задать по телефону:<br>
            <a href="tel:+79137191188">+7 913 719-11-88</a> или в <a href="https://t.me/wamflag">Telegram</a></p>
        </div>
    </div>
</body>
</html>