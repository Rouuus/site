<?php
/**
 * Шаблон страницы: Каталог (WooCommerce Shop)
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>

<main id="fc-main" class="fc-page">
    <?php get_template_part( 'template-parts/pages/hero', null, [
        'title'    => 'Каталог',
        'subtitle' => 'Флаги, вымпелы, спортивная форма и рекламный текстиль',
    ] ); ?>

    <section class="fc-section">
        <div class="fc-container">
            <?php echo do_shortcode( '[products limit="12" columns="4" paginate="true"]' ); ?>
        </div>
    </section>
</main>

<?php get_footer(); ?>