<?php
/**
 * Функции дочерней темы Flag Center
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_enqueue_scripts', 'fc_enqueue_child_styles' );
function fc_enqueue_child_styles() {
    $theme_dir = get_stylesheet_directory();
    $theme_uri = get_stylesheet_directory_uri();
    $version   = wp_get_theme()->get( 'Version' );

    // 1. Подключаем базовый style.css (там только шапка темы)
    wp_enqueue_style( 'generatepress-child-style', get_stylesheet_uri(), array(), $version );

    // 2. Массив с файлами в нужном порядке
    $css_files = array(
        '1-base',
        '2-header',
        '3-home',
        '4-pages',
        '5-woocommerce',
        '6-responsive' // Адаптив всегда последним!
    );

    // 3. Цикл подключения
    foreach ( $css_files as $file ) {
        $file_path = $theme_dir . '/css/' . $file . '.css';
        
        // Проверяем, существует ли файл, чтобы не было ошибок
        if ( file_exists( $file_path ) ) {
            wp_enqueue_style(
                'fc-' . $file,
                $theme_uri . '/css/' . $file . '.css',
                array( 'generatepress-child-style' ), // Зависимость от главного файла
                $version
            );
        }
    }
}

/* ============================================================
   2. РЕГИСТРАЦИЯ МЕНЮ
   ============================================================ */
add_action( 'after_setup_theme', function() {
    register_nav_menus([
        'primary'     => 'Главное меню',
        'footer'      => 'Меню в подвале',
        'footer_shop' => 'Футер — Каталог',
        'footer_info' => 'Футер — Информация',
    ]);
} );

/* ============================================================
   3. ОЧИСТКА <HEAD> И ОТКЛЮЧЕНИЕ EMOJI
   ============================================================ */
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );
add_action( 'init', function() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
} );

/* ============================================================
   4. ШОРТКОД ЗАГОЛОВКА СЕКЦИИ
   ============================================================ */
add_shortcode( 'fc_title', function( $atts, $content = '' ) {
    return '<div class="fc-section-title"><h2>' . esc_html( $content ) . '</h2></div>';
} );

/* ============================================================
   5. СКРИПТЫ И СТИЛИ (JS)
   ============================================================ */

/**
 * Анимация появления блоков
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) entry.target.classList.add('is-visible');
        });
    }, { threshold: 0.12 });
    document.querySelectorAll('.fc-animate').forEach(function(el) {
        observer.observe(el);
    });
});
</script>
<?php }, 10 );

/**
 * JS для Hero-слайдера
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var slider = document.getElementById('fc-hero-slider');
    if (!slider) return;
    var slides = slider.querySelectorAll('.fc-hero__slide');
    var dotsBox = document.querySelector('.fc-hero__dots');
    var current = 0, total = slides.length;
    slides.forEach(function(_, i) {
        var btn = document.createElement('button');
        if (i === 0) btn.classList.add('is-active');
        btn.addEventListener('click', function() { goTo(i); });
        dotsBox.appendChild(btn);
    });
    var dots = dotsBox.querySelectorAll('button');
    function goTo(index) {
        current = (index + total) % total;
        slider.style.transform = 'translateX(-' + (current * 100) + '%)';
        dots.forEach(function(d, i) { d.classList.toggle('is-active', i === current); });
    }
    document.querySelector('.fc-hero__nav--prev').addEventListener('click', function() { goTo(current - 1); });
    document.querySelector('.fc-hero__nav--next').addEventListener('click', function() { goTo(current + 1); });
    setInterval(function() { goTo(current + 1); }, 6000);
});
</script>
<?php }, 20 );

/**
 * JS для мобильного меню и корзины
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var toggle = document.getElementById('fc-mobile-toggle');
    var menu   = document.getElementById('fc-mobile-menu');
    var close  = document.getElementById('fc-mobile-close');
    if (toggle && menu) {
        toggle.addEventListener('click', function() {
            menu.classList.add('is-open');
            document.body.classList.add('fc-menu-open');
        });
        close.addEventListener('click', function() {
            menu.classList.remove('is-open');
            document.body.classList.remove('fc-menu-open');
        });
        menu.addEventListener('click', function(e) {
            if (e.target === menu) {
                menu.classList.remove('is-open');
                document.body.classList.remove('fc-menu-open');
            }
        });
    }
    if (typeof jQuery !== 'undefined') {
        jQuery(document.body).on('added_to_cart removed_from_cart', function() {
            jQuery.get('/?wc-ajax=get_refreshed_fragments', function() { location.reload(); });
        });
    }
});
</script>
<?php }, 30 );

/**
 * JS для фильтров «Наши работы»
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var filters = document.querySelectorAll('.fc-works__filters button');
    var items   = document.querySelectorAll('.fc-works__grid--full .fc-work');
    if (!filters.length) return;
    filters.forEach(function(btn) {
        btn.addEventListener('click', function() {
            filters.forEach(function(b) { b.classList.remove('is-active'); });
            btn.classList.add('is-active');
            var filter = btn.getAttribute('data-filter');
            items.forEach(function(item) {
                var cat = item.getAttribute('data-cat');
                if (filter === 'all' || cat === filter) item.classList.remove('is-hidden');
                else item.classList.add('is-hidden');
            });
        });
    });
});
</script>
<?php }, 40 );

/**
 * JS для аккордеона категорий
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var toggles = document.querySelectorAll('.fc-cat-accordion__toggle');
    toggles.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var item = btn.closest('.fc-cat-accordion__item');
            item.classList.toggle('is-open');
        });
    });
    var activeItem = document.querySelector('.fc-cat-accordion__item.is-active');
    if (activeItem) activeItem.classList.add('is-open');
});
</script>
<?php }, 50 );

/**
 * JS для галереи и вкладок товара
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var mainImg = document.querySelector('.fc-gallery__main-img');
    var thumbs  = document.querySelectorAll('.fc-gallery__thumb');
    thumbs.forEach(function(thumb) {
        thumb.addEventListener('click', function() {
            var src = thumb.getAttribute('data-src');
            if (mainImg && src) {
                mainImg.setAttribute('src', src);
                mainImg.removeAttribute('srcset');
                thumbs.forEach(function(t) { t.classList.remove('is-active'); });
                thumb.classList.add('is-active');
            }
        });
    });
    var tabBtns   = document.querySelectorAll('.fc-tabs__btn');
    var tabPanels = document.querySelectorAll('.fc-tabs__panel');
    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var tab = btn.getAttribute('data-tab');
            tabBtns.forEach(function(b) { b.classList.remove('is-active'); });
            tabPanels.forEach(function(p) { p.classList.remove('is-active'); });
            btn.classList.add('is-active');
            var panel = document.querySelector('.fc-tabs__panel[data-panel="' + tab + '"]');
            if (panel) panel.classList.add('is-active');
        });
    });
});
</script>
<?php }, 60 );

/**
 * JS для модальных окон
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-fc-modal]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var target = btn.getAttribute('data-fc-modal');
            var modal = document.getElementById('fc-modal-' + target);
            if (modal) {
                modal.classList.add('is-open');
                modal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('fc-modal-open');
            }
        });
    });
    document.querySelectorAll('[data-fc-modal-close]').forEach(function(closeBtn) {
        closeBtn.addEventListener('click', function() {
            var modal = closeBtn.closest('.fc-modal');
            if (modal) {
                modal.classList.remove('is-open');
                modal.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('fc-modal-open');
            }
        });
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.fc-modal.is-open').forEach(function(modal) {
                modal.classList.remove('is-open');
                modal.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('fc-modal-open');
            });
        }
    });
});
</script>
<?php }, 70 );

/**
 * Лайтбокс для «Наших работ»
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var items = document.querySelectorAll('[data-lightbox]');
    if (!items.length) return;
    var lightbox = document.createElement('div');
    lightbox.id = 'fc-lightbox';
    lightbox.innerHTML = '<div class="fc-lightbox__overlay"></div><button class="fc-lightbox__close" aria-label="Закрыть">×</button><img class="fc-lightbox__img" src="" alt="">';
    document.body.appendChild(lightbox);
    var img = lightbox.querySelector('.fc-lightbox__img');
    var close = lightbox.querySelector('.fc-lightbox__close');
    var overlay = lightbox.querySelector('.fc-lightbox__overlay');
    function open(src) {
        img.src = src;
        lightbox.classList.add('is-open');
        document.body.classList.add('fc-lightbox-open');
    }
    function closeLightbox() {
        lightbox.classList.remove('is-open');
        document.body.classList.remove('fc-lightbox-open');
        setTimeout(function() { img.src = ''; }, 300);
    }
    items.forEach(function(item) {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            var src = item.getAttribute('href');
            if (src) open(src);
        });
    });
    close.addEventListener('click', closeLightbox);
    overlay.addEventListener('click', closeLightbox);
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeLightbox();
    });
});
</script>
<?php }, 80 );

/**
 * JS для карусели похожих товаров
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var lists = document.querySelectorAll('.related.products ul.products');
    if (!lists.length) return;
    lists.forEach(function(list) {
        var wrapper = document.createElement('div');
        wrapper.className = 'fc-related-wrap';
        list.parentNode.insertBefore(wrapper, list);
        wrapper.appendChild(list);
        var prev = document.createElement('button');
        var next = document.createElement('button');
        prev.className = 'fc-related-nav fc-related-nav--prev';
        next.className = 'fc-related-nav fc-related-nav--next';
        prev.innerHTML = '‹';
        next.innerHTML = '›';
        wrapper.appendChild(prev);
        wrapper.appendChild(next);
        prev.addEventListener('click', function() { list.scrollBy({ left: -300, behavior: 'smooth' }); });
        next.addEventListener('click', function() { list.scrollBy({ left: 300, behavior: 'smooth' }); });
    });
});
</script>
<?php }, 90 );

/* ============================================================
   6. WOOCOMMERCE — НАСТРОЙКИ И ФИЛЬТРЫ
   ============================================================ */

// Убираем заголовок страницы каталога
add_filter( 'woocommerce_show_page_title', '__return_false' );

// Убираем сайдбар на страницах WooCommerce
add_filter( 'generate_sidebar_layout', function( $layout ) {
    if (
        ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) ||
        ( function_exists( 'is_cart' ) && is_cart() ) ||
        ( function_exists( 'is_checkout' ) && is_checkout() ) ||
        ( function_exists( 'is_account_page' ) && is_account_page() )
    ) return 'no-sidebar';
    return $layout;
}, 20 );

// Похожие товары: 6 штук
add_filter( 'woocommerce_output_related_products_args', function( $args ) {
    $args['posts_per_page'] = 6;
    $args['columns']        = 2;
    return $args;
} );

// Убираем cross-sell
remove_action( 'woocommerce_after_cart_table', 'woocommerce_cross_sell_display' );
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );

// Убираем строку доставки из «Итого»
add_filter( 'woocommerce_cart_needs_shipping', '__return_false' );

// Подпись под кнопкой оформления
add_action( 'woocommerce_after_cart_totals', function() {
    echo '<p style="text-align:center; font-size:13px; color:#6B7280; margin:16px 0 0;">Стоимость доставки рассчитывает менеджер после оформления заказа.</p>';
} );

// Упрощаем поля чекаута
add_filter( 'woocommerce_checkout_fields', function( $fields ) {
    unset( $fields['billing']['billing_company'] );
    unset( $fields['billing']['billing_postcode'] );
    unset( $fields['billing']['billing_state'] );
    unset( $fields['billing']['billing_country'] );
    unset( $fields['billing']['billing_address_2'] );
    unset( $fields['shipping']['shipping_company'] );
    unset( $fields['shipping']['shipping_postcode'] );
    unset( $fields['shipping']['shipping_state'] );
    unset( $fields['shipping']['shipping_country'] );
    unset( $fields['shipping']['shipping_address_2'] );

    $fields['billing']['billing_first_name']['label'] = 'Имя';
    $fields['billing']['billing_last_name']['label']  = 'Фамилия';
    $fields['billing']['billing_phone']['label']      = 'Телефон';
    $fields['billing']['billing_email']['label']      = 'Email';
    $fields['billing']['billing_city']['label']       = 'Город';
    $fields['billing']['billing_address_1']['label']  = 'Адрес';
    $fields['order']['order_comments']['label']       = 'Комментарий к заказу';

    return $fields;
} );

// Отключаем доставку на другой адрес
add_filter( 'woocommerce_ship_to_different_address_checked', '__return_false' );
add_filter( 'woocommerce_cart_needs_shipping_address', '__return_false' );

// Подпись под кнопкой «Оформить заказ»
add_action( 'woocommerce_review_order_after_payment', function() {
    echo '<p class="fc-checkout-note">После оформления заказа менеджер свяжется с вами для подтверждения деталей и способа оплаты.</p>';
} );

// Политика конфиденциальности в чекауте
add_filter( 'woocommerce_get_privacy_policy_text', function( $text, $type ) {
    if ( 'checkout' === $type ) {
        return 'Ваши персональные данные будут использованы для обработки заказа и в других целях, описанных в нашей <a href="/policy/">политике конфиденциальности</a>.';
    }
    return $text;
}, 20, 2 );

// «(optional)» → «(необязательно)»
add_filter( 'woocommerce_form_field', function( $field, $key, $args, $value ) {
    return str_replace( '(optional)', '(необязательно)', $field );
}, 10, 4 );

// Убираем заголовок «Спасибо за заказ»
add_filter( 'woocommerce_endpoint_order-received_title', function() { return ''; } );
add_filter( 'document_title_parts', function( $title ) {
    if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
        $title['title'] = 'Спасибо за заказ';
    }
    return $title;
} );
add_filter( 'generate_show_title', function( $show ) {
    if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) return false;
    return $show;
} );
add_filter( 'generate_show_title', function( $show ) {
    if ( function_exists( 'is_account_page' ) && is_account_page() ) return false;
    return $show;
} );
add_filter( 'generate_show_title', function( $show ) {
    if ( is_singular( 'post' ) ) return false;
    return $show;
} );

// Перевод статусов
add_filter( 'wc_order_statuses', function( $statuses ) {
    $statuses['wc-pending']    = 'Ожидает оплаты';
    $statuses['wc-processing'] = 'В обработке';
    $statuses['wc-on-hold']    = 'На удержании';
    $statuses['wc-completed']  = 'Выполнен';
    $statuses['wc-cancelled']  = 'Отменён';
    $statuses['wc-refunded']   = 'Возврат';
    $statuses['wc-failed']     = 'Ошибка';
    return $statuses;
} );

/* ============================================================
   7. ПЕРЕВОДЫ (GETTEXT) — ЕДИНЫЙ ФИЛЬТР
   ============================================================ */
add_filter( 'gettext', function( $translated, $original, $domain ) {
    if ( 'woocommerce' !== $domain ) return $translated;
    $map = [
        // Хлебные крошки
        'Home' => 'Главная',
        'Shop' => 'Каталог',
        // Счётчик
        'Showing %1$d–%2$d of %3$d results' => 'Показано %1$d–%2$d из %3$d товаров',
        'Showing the single result' => 'Показан 1 товар',
        'Showing all %d results' => 'Показаны все %d товаров',
        // Сортировка
        'Default sorting' => 'По умолчанию',
        'Sort by popularity' => 'По популярности',
        'Sort by average rating' => 'По рейтингу',
        'Sort by latest' => 'Сначала новые',
        'Sort by price: low to high' => 'Цена: по возрастанию',
        'Sort by price: high to low' => 'Цена: по убыванию',
        // Кнопки
        'Buy Now' => 'Купить',
        'Add to cart' => 'В корзину',
        'Read more' => 'Подробнее',
        'Select options' => 'Выбрать',
        'Related products' => 'Похожие товары',
        'Sale!' => 'Скидка!',
        'Out of stock' => 'Нет в наличии',
        'In stock' => 'В наличии',
        'Proceed to checkout' => 'Оформить заказ',
        'Continue shopping' => 'Продолжить покупки',
        'Update cart' => 'Обновить корзину',
        'Apply coupon' => 'Применить купон',
        'Subtotal' => 'Подытог',
        'Coupon:' => 'Купон:',
        'Coupon code' => 'Код купона',
        'Cart' => 'Корзина',
        'Product' => 'Товар',
        'Price' => 'Цена',
        'Quantity' => 'Количество',
        'Your cart is currently empty.' => 'Ваша корзина пуста.',
        'Return to shop' => 'Вернуться в каталог',
        'Remove this item' => 'Удалить этот товар',
        'My Account' => 'Личный кабинет',
        'Dashboard' => 'Главная',
        'Orders' => 'Заказы',
        'Downloads' => 'Загрузки',
        'Addresses' => 'Адреса',
        'Account details' => 'Данные аккаунта',
        'Log out' => 'Выйти',
        'Logout' => 'Выйти',
        'Login' => 'Войти',
        'Register' => 'Зарегистрироваться',
        'Username or email address' => 'Имя пользователя или Email',
        'Password' => 'Пароль',
        'Remember me' => 'Запомнить меня',
        'Lost your password?' => 'Забыли пароль?',
        'Email address' => 'Email',
        'Billing address' => 'Адрес доставки',
        'Shipping address' => 'Адрес получателя',
    ];
    return $map[ $original ] ?? $translated;
}, 20, 3 );

/* ============================================================
   8. ТИПЫ ЗАПИСЕЙ
   ============================================================ */

// Баннеры
add_action( 'init', function() {
    register_post_type( 'fc_banner', [
        'labels' => [
            'name'          => 'Баннеры',
            'singular_name' => 'Баннер',
            'add_new'       => 'Добавить баннер',
            'add_new_item'  => 'Новый баннер',
            'edit_item'     => 'Редактировать баннер',
            'all_items'     => 'Все баннеры',
            'menu_name'     => 'Баннеры',
        ],
        'public'          => false,
        'show_ui'         => true,
        'show_in_menu'    => true,
        'menu_icon'       => 'dashicons-images-alt2',
        'menu_position'   => 20,
        'supports'        => [ 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ],
        'has_archive'     => false,
        'rewrite'         => false,
        'capability_type' => 'post',
    ] );
} );

// Мета-поля для баннеров (кнопка)
add_action( 'add_meta_boxes', function() {
    add_meta_box( 'fc_banner_button', 'Кнопка баннера', 'fc_banner_button_callback', 'fc_banner', 'normal', 'high' );
} );
function fc_banner_button_callback( $post ) {
    wp_nonce_field( 'fc_banner_button_save', 'fc_banner_button_nonce' );
    $btn_text = get_post_meta( $post->ID, '_fc_btn_text', true );
    $btn_link = get_post_meta( $post->ID, '_fc_btn_link', true );
    ?>
    <p>
        <label for="fc_btn_text"><strong>Текст кнопки:</strong></label><br>
        <input type="text" id="fc_btn_text" name="fc_btn_text" value="<?php echo esc_attr( $btn_text ); ?>" placeholder="Например: Заказать печать" style="width: 100%; padding: 8px;">
    </p>
    <p>
        <label for="fc_btn_link"><strong>Ссылка кнопки:</strong></label><br>
        <input type="text" id="fc_btn_link" name="fc_btn_link" value="<?php echo esc_attr( $btn_link ); ?>" placeholder="Например: /shop/" style="width: 100%; padding: 8px;">
        <small>Можно указать: /shop/ — или полный URL https://wamflag.ru/shop/</small>
    </p>
    <?php
}
add_action( 'save_post_fc_banner', function( $post_id ) {
    if ( ! isset( $_POST['fc_banner_button_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['fc_banner_button_nonce'], 'fc_banner_button_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    if ( isset( $_POST['fc_btn_text'] ) ) update_post_meta( $post_id, '_fc_btn_text', sanitize_text_field( $_POST['fc_btn_text'] ) );
    if ( isset( $_POST['fc_btn_link'] ) ) update_post_meta( $post_id, '_fc_btn_link', esc_url_raw( $_POST['fc_btn_link'] ) );
} );

// «Наши работы»
add_action( 'init', function() {
    register_post_type( 'fc_work', [
        'labels' => [
            'name'               => 'Наши работы',
            'singular_name'      => 'Работа',
            'add_new'            => 'Добавить работу',
            'add_new_item'       => 'Новая работа',
            'edit_item'          => 'Редактировать работу',
            'all_items'          => 'Все работы',
            'menu_name'          => 'Наши работы',
        ],
        'public'             => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'menu_icon'          => 'dashicons-portfolio',
        'menu_position'      => 21,
        'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ],
        'has_archive'        => false,
        'rewrite'            => [ 'slug' => 'works' ],
        'capability_type'    => 'post',
        'show_in_rest'       => true,
    ] );

    register_taxonomy( 'fc_work_cat', 'fc_work', [
        'labels' => [
            'name'          => 'Категории работ',
            'singular_name' => 'Категория',
            'add_new_item'  => 'Добавить категорию',
            'all_items'     => 'Все категории',
            'menu_name'     => 'Категории работ',
        ],
        'public'            => true,
        'hierarchical'      => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
        'rewrite'           => [ 'slug' => 'works-category' ],
    ] );
} );

/* ============================================================
   9. ОТКЛЮЧЕНИЕ КОММЕНТАРИЕВ
   ============================================================ */
add_action( 'admin_init', function() {
    global $pagenow;
    if ( $pagenow === 'edit-comments.php' ) {
        wp_safe_redirect( admin_url() );
        exit;
    }
    remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
    remove_menu_page( 'edit-comments.php' );
} );
add_filter( 'comments_open', '__return_false', 20, 2 );
add_filter( 'pings_open', '__return_false', 20, 2 );
add_action( 'init', function() {
    remove_post_type_support( 'post', 'comments' );
    remove_post_type_support( 'page', 'comments' );
} );

/* ============================================================
   10. ОТКЛЮЧЕНИЕ SHORTPIXEL ДЛЯ ТЕМЫ
   ============================================================ */
add_filter( 'spai_should_optimize', function( $should, $url ) {
    if ( strpos( $url, '/wp-content/themes/generatepress-child/' ) !== false ) {
        return false;
    }
    return $should;
}, 10, 2 );
/**
 * Модальные окна — принудительный JS (жёсткий)
 */
add_action( 'wp_footer', function() { ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Открытие
    document.querySelectorAll('[data-fc-modal]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            var target = btn.getAttribute('data-fc-modal');
            var modal = document.getElementById('fc-modal-' + target);
            if (modal) {
                modal.classList.add('is-open');
                modal.style.display = 'flex';
                modal.style.opacity = '1';
                modal.style.visibility = 'visible';
                document.body.classList.add('fc-modal-open');
            }
        });
    });

    // Закрытие
    document.querySelectorAll('[data-fc-modal-close]').forEach(function(closeBtn) {
        closeBtn.addEventListener('click', function() {
            var modal = closeBtn.closest('.fc-modal');
            if (modal) {
                modal.classList.remove('is-open');
                modal.style.display = '';
                modal.style.opacity = '';
                modal.style.visibility = '';
                document.body.classList.remove('fc-modal-open');
            }
        });
    });

    // Esc
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.fc-modal.is-open').forEach(function(modal) {
                modal.classList.remove('is-open');
                modal.style.display = '';
                modal.style.opacity = '';
                modal.style.visibility = '';
                document.body.classList.remove('fc-modal-open');
            });
        }
    });
});
</script>
<?php }, 999 );
// Вывод описания категории ПЕРЕД панелью сортировки
add_action( 'woocommerce_before_shop_loop', 'fc_custom_category_description', 5 );
function fc_custom_category_description() {
    // Проверяем, что мы находимся на странице категории
    if ( is_product_category() ) {
        $term = get_queried_object();
        $description = term_description( $term->term_id, $term->taxonomy );
        
        // Если описание не пустое — выводим его
        if ( ! empty( $description ) ) {
            echo '<div class="fc-custom-term-description">' . wpautop( $description ) . '</div>';
        }
    }
}
// Вставка плашки через JS (если хуки не работают)
add_action( 'wp_footer', 'fc_inject_price_notice_js' );
function fc_inject_price_notice_js() {
    if ( ! is_product() ) return;
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Ищем кнопку "В корзину"
        var addToCartBtn = document.querySelector('.single_add_to_cart_button');
        if (addToCartBtn) {
            // Создаем плашку
            var notice = document.createElement('div');
            notice.className = 'fc-product-price-notice';
            notice.innerHTML = '<p><strong>Внимание:</strong> Цена указана за базовую комплектацию. Итоговая стоимость зависит от ткани, размера и тиража и рассчитывается индивидуально. Уточните у менеджера.</p>';
            
            // Вставляем её перед кнопкой (или после блока срока изготовления)
            var termBlock = document.querySelector('.fc-product__term'); 
            if (termBlock) {
                termBlock.parentNode.insertBefore(notice, termBlock.nextSibling);
            } else {
                addToCartBtn.parentNode.insertBefore(notice, addToCartBtn);
            }
        }
    });
    </script>
    <?php
}
// Включаем визуальный редактор для описаний категорий WooCommerce
add_action( 'init', function() {
    if ( ! class_exists( 'WooCommerce' ) ) return;
    
    // Убираем простое текстовое поле и ставим полноценный редактор
    remove_filter( 'pre_term_description', 'wp_filter_kses' );
    remove_filter( 'term_description', 'wp_kses_data' );
    
    add_filter( 'product_cat_edit_form_fields', function( $term ) {
        $settings = array( 'textarea_name' => 'description', 'textarea_rows' => 10, 'media_buttons' => false, 'teeny' => false );
        ?>
        <tr class="form-field">
            <th scope="row" valign="top"><label for="description">Описание</label></th>
            <td>
                <?php wp_editor( html_entity_decode( $term->description, ENT_QUOTES, 'UTF-8' ), 'description', $settings ); ?>
                <p class="description">Описание по умолчанию не отображается, однако некоторые темы могут его показывать.</p>
            </td>
        </tr>
        <?php
    }, 10, 1 );
});
add_action( 'user_register', 'ym_track_user_registration' );
function ym_track_user_registration( $user_id ) {
    // Этот код выполнится только после успешной регистрации
    // Замените 113688856 на номер вашего счетчика
    echo "<script>if (typeof ym === 'function') ym(113688856, 'reachGoal', 'user_registered');</script>";
}