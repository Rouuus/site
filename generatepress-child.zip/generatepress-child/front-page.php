<?php
/**
 * Шаблон главной страницы Flag Center
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
?>

<main id="fc-main" class="fc-home">

    <?php get_template_part( 'template-parts/home/hero' ); ?>
    <?php get_template_part( 'template-parts/home/advantages' ); ?>
    <?php get_template_part( 'template-parts/home/sale' ); ?>
    <?php get_template_part( 'template-parts/home/products' ); ?>
    <?php get_template_part( 'template-parts/home/tech' ); ?>
    <?php get_template_part( 'template-parts/home/how' ); ?>
    <?php get_template_part( 'template-parts/home/works' ); ?>
    <?php get_template_part( 'template-parts/home/clients' ); ?>
    <?php get_template_part( 'template-parts/home/form' ); ?>
    <?php get_template_part( 'template-parts/home/contacts' ); ?>

</main>

<?php get_footer(); ?>