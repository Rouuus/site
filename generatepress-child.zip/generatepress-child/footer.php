<?php
/**
 * Кастомный футер Flag Center
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<footer class="fc-footer">

    <!-- ВЕРХНЯЯ ЧАСТЬ -->
    <div class="fc-footer__top">
        <div class="fc-container">
            <div class="fc-footer__grid">

                <!-- Колонка 1: Лого + описание -->
                <div class="fc-footer__col fc-footer__col--brand">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="fc-footer__logo">
                        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/logo-white.svg' ); ?>" alt="<?php bloginfo( 'name' ); ?>">
                    </a>
                    <p class="fc-footer__desc">
                        Производство флагов, вымпелов и рекламного текстиля в Новосибирске с 2008 года. Работаем по всей России.
                    </p>
                    <div class="fc-footer__socials">
                        <a href="https://t.me/+79137191188" target="_blank" rel="noopener" aria-label="Telegram">
                           <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-telegram-w.webp' ); ?>" alt="Telegram" width="24" height="24">
                        </a>
                        <a href="https://wa.me/79137191188" target="_blank" rel="noopener" aria-label="MAX">
                            <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-maks-w.webp' ); ?>" alt="MAX" width="16" height="16">
                        </a>
                        <a href="https://vk.ru/flagcenter" target="_blank" rel="noopener" aria-label="VK">
                            <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/icon-vk-w.webp' ); ?>" alt="Telegram" width="24" height="24">
                        </a>
                    </div>
                </div>

                <!-- Колонка 2: Каталог -->
                <div class="fc-footer__col">
                    <h4 class="fc-footer__title">Каталог</h4>
                    <?php
                    wp_nav_menu([
                        'theme_location' => 'footer_shop',
                        'container'      => false,
                        'menu_class'     => 'fc-footer__list',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    ]);
                    ?>
                </div>

                <!-- Колонка 3: Информация -->
                <div class="fc-footer__col">
                    <h4 class="fc-footer__title">Информация</h4>
                    <?php
                    wp_nav_menu([
                        'theme_location' => 'footer_info',
                        'container'      => false,
                        'menu_class'     => 'fc-footer__list',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    ]);
                    ?>
                </div>

                <!-- Колонка 4: Контакты -->
                <div class="fc-footer__col">
                    <h4 class="fc-footer__title">Контакты</h4>
                    <ul class="fc-footer__list fc-footer__contacts">
                        <li>
                            <a href="tel:+73833251222">+7 (383) 325-12-22</a>
                        </li>
                        <li>
                            <a href="tel:+79137191188">+7 913 719-11-88</a>
                        </li>
                        <li>
                            <a href="mailto:flagcenter@flagcenter.ru">flagcenter@flagcenter.ru</a>
                        </li>
                        <li class="fc-footer__address">
    Новосибирск,<br>ул. Мусы Джалиля, 21/5
</li>
<li class="fc-footer__hours">
    Пн–Пт: 8:30 – 17:00
</li>
                    </ul>
                    <button type="button" class="fc-btn fc-btn--accent fc-footer__callback" data-fc-modal="callback">
                        Заказать звонок
                    </button>
                </div>

            </div>
        </div>
    </div>

    <!-- НИЖНЯЯ ЧАСТЬ -->
    <div class="fc-footer__bottom">
        <div class="fc-container fc-footer__bottom-inner">
            <div class="fc-footer__copy">
                © <?php echo date( 'Y' ); ?> «Флаг Центр». Все права защищены.
            </div>
            <div class="fc-footer__links">
                <a href="/policy/">Политика конфиденциальности</a>
                <a href="/oferta/">Публичная оферта</a>
            </div>
        </div>
    </div>

</footer>
<!-- МОДАЛЬНОЕ ОКНО: ЗАКАЗАТЬ ЗВОНОК -->
<div class="fc-modal" id="fc-modal-callback" aria-hidden="true">
    <div class="fc-modal__overlay" data-fc-modal-close></div>
    <div class="fc-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="fc-modal-title">
        <button type="button" class="fc-modal__close" data-fc-modal-close aria-label="Закрыть">×</button>

        <div class="fc-modal__body">
            <h3 class="fc-modal__title" id="fc-modal-title">Заказать звонок</h3>
            <p class="fc-modal__subtitle">Оставьте телефон — перезвоним в течение 15 минут</p>

            <div class="fc-modal__form">
                <?php echo do_shortcode('[contact-form-7 id="0ba5ca4"]'); // ← замени XXX на ID формы «Заказать звонок» ?>
            </div>
        </div>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>