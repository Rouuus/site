<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<main id="fc-main" class="fc-page">
    <?php get_template_part( 'template-parts/pages/contacts' ); ?>
</main>
<?php get_footer(); ?>