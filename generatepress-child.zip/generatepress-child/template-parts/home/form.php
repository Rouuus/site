<?php
/**
 * Секция: Форма обратной связи (Contact Form 7)
 */
?>

<section class="fc-section fc-form" id="fc-form">
    <div class="fc-container fc-container--narrow">

        <div class="fc-section-title fc-animate">
            <h2>Оставьте заявку</h2>
            <p class="fc-form__subtitle">Менеджер свяжется с вами в течение 15 минут</p>
        </div>

        <div class="fc-form__box fc-animate">
            <?php echo do_shortcode('[contact-form-7 id="091f6fa" title="Заявка с главной"]'); ?>
        </div>

    </div>
</section>