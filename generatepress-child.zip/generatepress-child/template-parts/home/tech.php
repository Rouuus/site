<?php
/**
 * Секция: Наши технологии (DTF и сублимация)
 */
?>

<section class="fc-section fc-tech">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Наши технологии</h2>
        </div>

        <div class="fc-tech__grid">

            <div class="fc-tech__item fc-animate">
                <div class="fc-tech__image">
                    <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/dtf.webp' ); ?>" alt="DTF-печать">
                </div>
                <div class="fc-tech__body">
                    <h3>DTF-печать</h3>
                    <p>Яркая печать на футболках, худи, шортах и любой одежде. Подходит для мелких партий и единичных заказов. Стойкость к стирке — до 100 циклов.</p>
                </div>
            </div>

            <div class="fc-tech__item fc-animate">
                <div class="fc-tech__image">
                    <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/sublimation.webp' ); ?>" alt="Сублимация">
                </div>
                <div class="fc-tech__body">
                    <h3>Сублимация</h3>
                    <p>Двухсторонняя печать на флагах, вымпелах и рекламном текстиле. Рисунок одинаково яркий с обеих сторон. Идеально для улицы и помещений.</p>
                </div>
            </div>

        </div>
    </div>
</section>