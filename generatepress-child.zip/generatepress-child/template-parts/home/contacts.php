<?php
/**
 * Секция: Контакты + карта
 */
?>

<section class="fc-section fc-contacts">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Контакты</h2>
        </div>

        <div class="fc-contacts__grid fc-animate">

            <div class="fc-contact">
    <span class="fc-contact__label">Телефон</span>
    <a href="tel:+73833251222" class="fc-contact__value">+7 (383) 325-12-22</a>
    <a href="tel:+79137191188" class="fc-contact__value">+7 913 719-11-88</a>
</div>

            <div class="fc-contact">
                <span class="fc-contact__label">Telegram</span>
                <a href="https://t.me/flagcenter" class="fc-contact__value">@flagcenter</a>
            </div>

            <div class="fc-contact">
                <span class="fc-contact__label">MAX</span>
                <a href="https://max.ru/id5408257072_biz" class="fc-contact__value">+7 913 719-11-88</a>
            </div>

            <div class="fc-contact">
    <span class="fc-contact__label">Адрес</span>
    <span class="fc-contact__value">Новосибирск, ул. Мусы Джалиля, 21/5</span>
    <span class="fc-contact__hours">Пн–Пт: 8:30 – 17:00</span>
</div>

        </div>

        <div class="fc-contacts__map fc-animate">
            <iframe
                src="https://yandex.ru/map-widget/v1/?text=Новосибирск%20улица%20Мусы%20Джалиля%2021%2F5&z=16"
                width="100%" height="400" frameborder="0" loading="lazy">
            </iframe>
        </div>

    </div>
</section>