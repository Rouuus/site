<?php
/**
 * Секция: Преимущества (4 карточки)
 */
?>

<section class="fc-section fc-advantages">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Почему заказывают у нас</h2>
        </div>

        <div class="fc-grid fc-grid--4">

            <div class="fc-advantage fc-animate">
                <div class="fc-advantage__num">01</div>
                <h3 class="fc-advantage__title">Своё производство</h3>
                <p class="fc-advantage__text">Цех в Новосибирске. Не посредники, не перекупщики.</p>
            </div>

            <div class="fc-advantage fc-animate">
                <div class="fc-advantage__num">02</div>
                <h3 class="fc-advantage__title">Отшиваем за 1 день</h3>
                <p class="fc-advantage__text">Если очень срочно — сделаем в кратчайшие сроки.</p>
            </div>

            <div class="fc-advantage fc-animate">
                <div class="fc-advantage__num">03</div>
                <h3 class="fc-advantage__title">Два вида принтеров</h3>
                <p class="fc-advantage__text">Подберём технологию под ваш макет и задачу.</p>
            </div>

            <div class="fc-advantage fc-animate">
                <div class="fc-advantage__num">04</div>
                <h3 class="fc-advantage__title">От 1 штуки</h3>
                <p class="fc-advantage__text">Берём и единичные заказы, и крупные тиражи.</p>
            </div>

        </div>
    </div>
</section>