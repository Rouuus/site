<?php
/**
 * Секция: Как мы работаем (4 шага)
 */
?>

<section class="fc-section fc-how">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Как мы работаем</h2>
        </div>

        <div class="fc-how__steps">

            <div class="fc-how__step fc-animate">
                <div class="fc-how__num">1</div>
                <h3>Заявка</h3>
                <p>Вы оставляете заявку на сайте, пишете в мессенджер или звоните.</p>
            </div>

            <div class="fc-how__step fc-animate">
                <div class="fc-how__num">2</div>
                <h3>Макет и расчёт</h3>
                <p>Менеджер уточняет детали, помогает с макетом и считает стоимость.</p>
            </div>

            <div class="fc-how__step fc-animate">
                <div class="fc-how__num">3</div>
                <h3>Печать и пошив</h3>
                <p>Запускаем в производство. Срочные заказы отшиваем за 1 день.</p>
            </div>

            <div class="fc-how__step fc-animate">
                <div class="fc-how__num">4</div>
                <h3>Доставка</h3>
                <p>Отправляем по Новосибирску, Бердску и всей России.</p>
            </div>

        </div>
    </div>
</section>