<?php
/**
 * Секция: С нами работают
 */
?>

<section class="fc-section fc-clients">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>С нами работают</h2>
        </div>

        <div class="fc-clients__row fc-animate">
            <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/client-1.webp' ); ?>" alt="Пятёрочка">
<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/images/client-2.webp' ); ?>" alt="Мария-Ра">
        </div>

    </div>
</section>