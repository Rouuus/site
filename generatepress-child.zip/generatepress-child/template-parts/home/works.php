<?php
get_template_part( 'template-parts/pages/hero', null, [
    'title'    => 'Наши работы',
    'subtitle' => 'Примеры выполненных заказов для крупных компаний и организаций',
] );
?>

<section class="fc-section">
    <div class="fc-container">

        <?php
        // Фильтры — категории работ
        $categories = get_terms([
            'taxonomy'   => 'fc_work_cat',
            'hide_empty' => true,
        ]);
        ?>

        <?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
            <div class="fc-works__filters fc-animate">
                <button type="button" class="is-active" data-filter="all">Все</button>
                <?php foreach ( $categories as $cat ) : ?>
                    <button type="button" data-filter="<?php echo esc_attr( $cat->slug ); ?>">
                        <?php echo esc_html( $cat->name ); ?>
                    </button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php
        // Запрос работ
        $works = new WP_Query([
            'post_type'      => 'fc_work',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
            'post_status'    => 'publish',
        ]);

        if ( $works->have_posts() ) :
            ?>
            <div class="fc-works__grid fc-works__grid--full">

                <?php while ( $works->have_posts() ) : $works->the_post();
                    $terms = get_the_terms( get_the_ID(), 'fc_work_cat' );
                    $cat_slugs = '';
                    $cat_names = [];
                    if ( $terms && ! is_wp_error( $terms ) ) {
                        foreach ( $terms as $term ) {
                            $cat_slugs .= $term->slug . ' ';
                            $cat_names[] = $term->name;
                        }
                    }
                    $cat_slugs = trim( $cat_slugs );
                    ?>

                    <a href="<?php the_post_thumbnail_url( 'full' ); ?>"
                       class="fc-work fc-card fc-animate"
                       data-cat="<?php echo esc_attr( $cat_slugs ); ?>"
                       data-lightbox="works">

                        <div class="fc-work__image">
                            <?php the_post_thumbnail( 'large' ); ?>
                        </div>
                        <div class="fc-work__body">
                            <?php if ( ! empty( $cat_names ) ) : ?>
                                <span class="fc-work__cat"><?php echo esc_html( implode( ', ', $cat_names ) ); ?></span>
                            <?php endif; ?>
                            <h3><?php the_title(); ?></h3>
                            <?php if ( has_excerpt() ) : ?>
                                <p><?php echo esc_html( get_the_excerpt() ); ?></p>
                            <?php endif; ?>
                        </div>

                    </a>

                <?php endwhile; wp_reset_postdata(); ?>

            </div>
        <?php else : ?>
            <p style="text-align:center; color:#6B7280; padding:40px 0;">
                Работы пока не добавлены. Добавьте их в админке → «Наши работы».
            </p>
        <?php endif; ?>

    </div>
</section>

