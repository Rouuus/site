<?php
/**
 * Секция: Популярные товары
 * - Исключает товары из категории "sale" (Распродажа)
 * - Показывает только товары с меткой "popular"
 */

$popular_products = new WP_Query([
    'post_type'      => 'product',
    'posts_per_page' => 8,
    'post_status'    => 'publish',
    'orderby'        => 'meta_value_num',
    'meta_key'       => 'total_sales',
    'order'          => 'DESC',
    'tax_query'      => [
        'relation' => 'AND',
        [
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => 'sale',
            'operator' => 'NOT IN',
        ],
        [
            'taxonomy' => 'product_tag',
            'field'    => 'slug',
            'terms'    => 'popular',
        ],
    ],
]);
?>

<section class="fc-section fc-products">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Популярные товары</h2>
        </div>

        <?php if ( $popular_products->have_posts() ) : ?>
            <div class="woocommerce">
    <ul class="products columns-4">
        <?php while ( $popular_products->have_posts() ) : $popular_products->the_post(); ?>
            <?php wc_get_template_part( 'content', 'product' ); ?>
        <?php endwhile; wp_reset_postdata(); ?>
    </ul>
</div>
        <?php else : ?>
            <p style="text-align:center; color:#6B7280; padding:40px 0;">
                Отметьте товары меткой «Популярное», чтобы они появились здесь.
            </p>
        <?php endif; ?>

        <div class="fc-products__more fc-animate">
            <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="fc-btn fc-btn--outline">Весь каталог</a>
        </div>

    </div>
</section>