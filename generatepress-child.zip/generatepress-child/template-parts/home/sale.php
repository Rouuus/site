<?php
/**
 * Секция: Распродажа на главной
 * Выводит товары из категории "sale"
 */

// Получаем товары из категории "Распродажа"
$sale_products = new WP_Query([
    'post_type'      => 'product',
    'posts_per_page' => 4,
    'post_status'    => 'publish',
    'tax_query'      => [
        [
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => 'sale', // ← слаг вашей категории
        ],
    ],
    'orderby'        => 'date',
    'order'          => 'DESC',
]);

if ( ! $sale_products->have_posts() ) {
    return; // если нет товаров в распродаже — блок не выводим
}
?>

<section class="fc-section fc-sale">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Распродажа</h2>
            <p class="fc-sale__subtitle">Акционные товары и ликвидация остатков. Ограниченное количество.</p>
        </div>

        <div class="fc-sale__grid">

             <?php while ( $sale_products->have_posts() ) : $sale_products->the_post();
                global $product; ?>

                <div class="fc-sale-card fc-animate">
                    
                    <!-- Ссылка на товар (только для картинки и названия) -->
                    <a href="<?php the_permalink(); ?>" class="fc-sale-card__link">
                        <div class="fc-sale-card__badge">Скидка</div>

                        <div class="fc-sale-card__image">
                            <?php echo woocommerce_get_product_thumbnail( 'woocommerce_thumbnail' ); ?>
                        </div>

                        <div class="fc-sale-card__body">
                            <h3 class="fc-sale-card__title"><?php the_title(); ?></h3>
                            <div class="fc-sale-card__price"><?php echo $product->get_price_html(); ?></div>
                        </div>
                    </a>

                    <!-- Настоящая кнопка "В корзину" от WooCommerce -->
                    <div class="fc-sale-card__btn-wrap">
                        <?php woocommerce_template_loop_add_to_cart(); ?>
                    </div>

                </div>

            <?php endwhile; wp_reset_postdata(); ?>

        </div>

        <div class="fc-sale__more fc-animate">
            <a href="<?php echo esc_url( get_term_link( 'sale', 'product_cat' ) ); ?>" class="fc-btn fc-btn--accent">
                Все акции →
            </a>
        </div>

    </div>
</section>