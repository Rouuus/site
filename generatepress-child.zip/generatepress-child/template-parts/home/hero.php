<?php
/**
 * Секция: Hero-слайдер
 * Баннеры берутся из типа записей fc_banner
 */

$banners = get_posts([
    'post_type'      => 'fc_banner',
    'posts_per_page' => -1,
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'post_status'    => 'publish',
]);

if ( empty( $banners ) ) {
    ?>
    <section class="fc-hero">
        <div class="fc-hero__slider">
            <div class="fc-hero__slide"
                 style="background: linear-gradient(180deg, rgba(0,0,0,.55) 0%, rgba(0,0,0,.65) 100%);">
                <div class="fc-hero__inner">
                    <h1 class="fc-hero__title">Двухсторонняя печать?<br>Только яркая!</h1>
                    <p class="fc-hero__subtitle">Цвета, которые видны с любой точки</p>
                    <a href="/shop/" class="fc-btn fc-btn--accent">Заказать печать →</a>
                </div>
            </div>
        </div>
    </section>
    <?php
    return;
}
?>

<section class="fc-hero">
    <div class="fc-hero__slider" id="fc-hero-slider">

        <?php foreach ( $banners as $banner ) :
            $bg_id    = get_post_thumbnail_id( $banner->ID );
            $bg_url   = $bg_id ? wp_get_attachment_image_url( $bg_id, 'full' ) : '';
            $title    = get_the_title( $banner->ID );
            $sub      = get_the_excerpt( $banner->ID );
            $btn_text = get_post_meta( $banner->ID, '_fc_btn_text', true );
            $btn_link = get_post_meta( $banner->ID, '_fc_btn_link', true );
            ?>

            <div class="fc-hero__slide"
                 style="background-image:
                     linear-gradient(180deg, rgba(0,0,0,.55) 0%, rgba(0,0,0,.65) 100%),
                     url('<?php echo esc_url( $bg_url ); ?>');
                     background-size: cover;
                     background-position: center;">

                <div class="fc-hero__inner">
                    <h1 class="fc-hero__title"><?php echo esc_html( $title ); ?></h1>

                    <?php if ( $sub ) : ?>
                        <p class="fc-hero__subtitle"><?php echo esc_html( $sub ); ?></p>
                    <?php endif; ?>

                    <?php if ( $btn_text && $btn_link ) : ?>
                        <div class="fc-hero__button">
                            <a href="<?php echo esc_url( $btn_link ); ?>" class="fc-btn fc-btn--accent">
                                <?php echo esc_html( $btn_text ); ?> →
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php endforeach; ?>

    </div>

    <?php if ( count( $banners ) > 1 ) : ?>
        <button class="fc-hero__nav fc-hero__nav--prev" aria-label="Назад">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </button>
        <button class="fc-hero__nav fc-hero__nav--next" aria-label="Вперёд">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </button>
        <div class="fc-hero__dots"></div>
    <?php endif; ?>

</section>