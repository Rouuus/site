<?php
get_template_part( 'template-parts/pages/hero', null, [
    'title'    => 'Контакты',
    'subtitle' => 'Свяжитесь с нами удобным способом',
] );
?>

<section class="fc-section">
    <div class="fc-container">

        <!-- 1. Контакты (телефоны, соцсети, адрес, часы работы) -->
        <div class="fc-contacts__grid fc-animate">

            <div class="fc-contact">
                <span class="fc-contact__label">Телефоны</span>
                <a href="tel:+73833251222" class="fc-contact__value">+7 (383) 325-12-22</a>
                <a href="tel:+79137191188" class="fc-contact__value">+7 (913) 719-11-88</a>
            </div>

            <div class="fc-contact">
                <span class="fc-contact__label">Email</span>
                <a href="mailto:flagcenter@flagcenter.ru" class="fc-contact__value">flagcenter@flagcenter.ru</a>
            </div>

            <div class="fc-contact">
                <span class="fc-contact__label">Мессенджеры</span>
                <a href="https://t.me/flagcenter" target="_blank" class="fc-contact__value">Telegram: @flagcenter</a>
                <a href="https://max.ru/id5408257072_biz" target="_blank" class="fc-contact__value">MAX: +7 913 719-11-88</a>
            </div>

            <div class="fc-contact">
                <span class="fc-contact__label">Адрес</span>
                <span class="fc-contact__value">Новосибирск, ул. Мусы Джалиля, 21/5</span>
                <span class="fc-contact__hours">Пн–Пт: 8:30 – 17:00</span>
            </div>

        </div>

        <!-- 2. Карта -->
        <div class="fc-contacts__map fc-animate">
            <iframe
                src="https://yandex.ru/map-widget/v1/?text=Новосибирск%20улица%20Мусы%20Джалиля%2021%2F5&z=16"
                width="100%" height="440" frameborder="0" loading="lazy">
            </iframe>
        </div>

    </div>
</section>

<!-- 3. Отделы: заказы, реклама -->
<section class="fc-section fc-contacts-departments">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Отделы</h2>
        </div>

        <div class="fc-departments fc-animate">

            <div class="fc-department">
                <div class="fc-department__icon">📦</div>
                <h3>Вопросы по заказам</h3>
                <p>Уточнить статус заказа, сроки изготовления, доставку, оплату.</p>
                <a href="mailto:flagcenter@flagcenter.ru" class="fc-department__email">
                    flagcenter@flagcenter.ru
                </a>
            </div>

            <div class="fc-department">
                <div class="fc-department__icon">🤝</div>
                <h3>Реклама и сотрудничество</h3>
                <p>Партнёрство, корпоративные заказы, оптовые поставки, реклама.</p>
                <a href="mailto:info@flagcenter.ru" class="fc-department__email">
                    flagcenter@flagcenter.ru
                </a>
            </div>

        </div>

    </div>
</section>

<!-- 4. Форма обратной связи -->
<section class="fc-section fc-form" id="fc-form">
    <div class="fc-container fc-container--narrow">
        <div class="fc-section-title fc-animate">
            <h2>Обратная связь</h2>
            <p class="fc-form__subtitle">Проблемы с заказом, вопросы, предложения — напишите нам</p>
        </div>
        <div class="fc-form__box fc-animate">
            <?php echo do_shortcode('[contact-form-7 id="091f6fa"]'); ?>
        </div>
    </div>
</section>

<!-- 5. Реквизиты -->
<!-- 5. Реквизиты -->
<!-- 5. Реквизиты -->
<section class="fc-section fc-requisites">
    <div class="fc-container">

        <div class="fc-section-title fc-animate">
            <h2>Реквизиты</h2>
        </div>

        <div class="fc-requisites__box fc-animate">
            <table class="fc-requisites__table">
                <tbody>
                    <tr>
                        <th>Полное наименование</th>
                        <td>ООО ПТК «ФЛАГ ЦЕНТР»</td>
                    </tr>
                    <tr>
                        <th>ИНН</th>
                        <td>5408257072</td>
                    </tr>
                    <tr>
                        <th>КПП</th>
                        <td>540801001</td>
                    </tr>
                    <tr>
                        <th>ОГРН</th>
                        <td>1075473018235</td>
                    </tr>
                    <tr>
                        <th>Юридический адрес</th>
                        <td>630056, Новосибирская область, г. Новосибирск, ул. Софийская, д. 16</td>
                    </tr>
                    <tr>
                        <th>Телефоны</th>
                        <td>
                            <a href="tel:+73833251222">+7 (383) 325-12-22</a><br>
                            <a href="tel:+79137191188">+7 913 719-11-88</a>
                        </td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>
                            <a href="mailto:flagcenter@flagcenter.ru">flagcenter@flagcenter.ru</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
</section>