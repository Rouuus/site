<?php
get_template_part( 'template-parts/pages/hero', null, [
    'title'    => 'Доставка',
    'subtitle' => 'Получите заказ удобным способом — по Новосибирску, Бердску и всей России',
] );
?>

<section class="fc-section">
    <div class="fc-container">

        <div class="fc-delivery-grid">

            <div class="fc-delivery-card fc-animate">
                <div class="fc-delivery-card__icon">🚚</div>
                <h3>Бесплатная доставка</h3>
                <p><strong>Действует для всех заказов.</strong></p>
                <p><strong>Территория:</strong> в пределах г. Новосибирск и г. Бердск.</p>
                <p><strong>Срок:</strong> доставим в удобный для вас промежуток после готовности заказа.</p>
                <p><strong>Как получить:</strong> укажите адрес в заказе — менеджер свяжется для согласования времени.</p>
            </div>

            <div class="fc-delivery-card fc-animate">
                <div class="fc-delivery-card__icon">🏭</div>
                <h3>Самовывоз</h3>
                <p>Бесплатно забрать готовый заказ с производства.</p>
                <p><strong>Адрес:</strong> Новосибирск, ул. Мусы Джалиля, 21/5.</p>
                <p><strong>Готовность:</strong> сообщим, когда заказ будет готов к выдаче.</p>
                <p>Предварительно согласуйте время с менеджером.</p>
            </div>

            <div class="fc-delivery-card fc-animate">
                <div class="fc-delivery-card__icon">🏢</div>
                <h3>Для корпоративных клиентов</h3>
                <p>Доставка до терминала транспортной компании в Новосибирске — за наш счёт.</p>
                <p>Оговаривается индивидуально в договоре.</p>
                <p>Отгрузка через любую удобную для вас ТК.</p>
            </div>

            <div class="fc-delivery-card fc-animate">
                <div class="fc-delivery-card__icon">🇷🇺</div>
                <h3>Доставка по России</h3>
                <p>Выбирайте любую транспортную компанию.</p>
                <p>Удобный пункт выдачи или курьер до двери.</p>
                <p>Стоимость рассчитывает менеджер индивидуально.</p>
            </div>

        </div>

        <div class="fc-cta fc-animate">
            <h2>Остались вопросы по доставке?</h2>
            <p>Позвоните или напишите — подберём оптимальный вариант.</p>
            <div class="fc-cta__buttons">
                                <a href="tel:+73833251222" class="fc-btn fc-btn--primary">+7 (383) 325-12-22</a>

                <a href="tel:+79137191188" class="fc-btn fc-btn--primary">+7 913 719-11-88</a>
                <a href="https://max.ru/id5408257072_biz" target="_blank" class="fc-btn fc-btn--outline">MAX</a>
            </div>
        </div>

    </div>
</section>