<?php
get_template_part( 'template-parts/pages/hero', null, [
    'title'    => 'О нас',
    'subtitle' => 'Производственно-торговая компания «Флаг Центр» — с 2008 года',
] );
?>

<section class="fc-section">
    <div class="fc-container fc-container--narrow">

        <div class="fc-about-text fc-animate">
            <p>Компания <strong>«Флаг Центр»</strong> — производитель флагов, вымпелов и рекламного текстиля в Новосибирске с 2008 года. Мы работаем на собственном оборудовании, поэтому можем изготовить флаг любого размера от 1 штуки, а также выполнить крупный тираж для организации или мероприятия.</p>

            <p>В нашем цехе два вида станков печати, что позволяет подобрать технологию под ваш макет: <strong>сублимационная печать и DTF-печать на ткани</strong>. Такого качества печати, как у нас, нет больше ни у кого в Новосибирске — рисунок  качественый и яркий.</p>

            <p>Мы изготавливаем государственные и корпоративные флаги, флаги городов и регионов, флаги на заказ с вашим логотипом, а также вымпелы, баннеры, наградные ленты и рекламный текстиль. Срок изготовления — от 1 дня. Доставляем по всей России.</p>

            <p>С нами работают крупные компании: <strong>«Пятёрочка», «Мария-Ра»</strong> и другие. Мы также изготавливаем флаги для школ, санаториев, спортивных клубов и государственных учреждений.</p>
        </div>

        <!-- Цифры -->
        <div class="fc-stats fc-animate">
            <div class="fc-stat">
                <div class="fc-stat__num">17+</div>
                <div class="fc-stat__label">лет на рынке</div>
            </div>
            <div class="fc-stat">
                <div class="fc-stat__num">2</div>
                <div class="fc-stat__label">технологии печати</div>
            </div>
            <div class="fc-stat">
                <div class="fc-stat__num">1</div>
                <div class="fc-stat__label">день на срочный заказ</div>
            </div>
            <div class="fc-stat">
                <div class="fc-stat__num">∞</div>
                <div class="fc-stat__label">тираж — от 1 шт</div>
            </div>
        </div>

        <!-- Преимущества -->
        <h2 class="fc-h2-center fc-animate">Почему выбирают нас</h2>
        <div class="fc-about-advantages fc-animate">
            <div class="fc-about-adv">
                <h3>Своё производство</h3>
                <p>Собственный цех в Новосибирске. Без посредников и перекупщиков.</p>
            </div>
            <div class="fc-about-adv">
                <h3>Собственная доставка</h3>
                <p>По Новосибирску и Бердску — бесплатно. По России — любой ТК.</p>
            </div>
            <div class="fc-about-adv">
                <h3>Гибкие условия</h3>
                <p>Работаем с юрлицами и физлицами, от 1 шт до крупных тиражей.</p>
            </div>
            <div class="fc-about-adv">
                <h3>Всегда в срок</h3>
                <p>Срочные заказы отшиваем за 1 день. Отвечаем за качество.</p>
            </div>
        </div>

    </div>
</section>

<section class="fc-section fc-form" id="fc-form">
    <div class="fc-container fc-container--narrow">
        <div class="fc-section-title fc-animate">
            <h2>Обсудим ваш проект?</h2>
            <p class="fc-form__subtitle">Оставьте заявку — перезвоним и поможем с выбором</p>
        </div>
        <div class="fc-form__box fc-animate">
            <?php echo do_shortcode('[contact-form-7 id="091f6fa" title="Заявка"]'); ?>
        </div>
    </div>
</section>