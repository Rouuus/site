<?php
/**
 * Общий hero для внутренних страниц
 * Параметры: $args['title'], $args['subtitle']
 */
$title    = $args['title']    ?? get_the_title();
$subtitle = $args['subtitle'] ?? '';
?>

<section class="fc-page-hero">
    <div class="fc-container">
        <h1 class="fc-page-hero__title"><?php echo esc_html( $title ); ?></h1>
        <?php if ( $subtitle ) : ?>
            <p class="fc-page-hero__subtitle"><?php echo esc_html( $subtitle ); ?></p>
        <?php endif; ?>
    </div>
</section>