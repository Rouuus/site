<?php
get_template_part( 'template-parts/pages/hero', null, [
    'title'    => 'Как заказать',
    'subtitle' => 'Получить наш товар очень просто — оформите заказ удобным способом',
] );
?>

<section class="fc-section">
    <div class="fc-container">

        <!-- Шаги -->
        <div class="fc-how__steps fc-animate">
            <div class="fc-how__step">
                <div class="fc-how__num">1</div>
                <h3>Заявка</h3>
                <p>Через форму на сайте, мессенджер, телефон или корзину.</p>
            </div>
            <div class="fc-how__step">
                <div class="fc-how__num">2</div>
                <h3>Согласование</h3>
                <p>Менеджер уточняет задачу, помогает с макетом, считает цену.</p>
            </div>
            <div class="fc-how__step">
                <div class="fc-how__num">3</div>
                <h3>Производство</h3>
                <p>Печатаем и отшиваем. Срочные заказы — за 1 день.</p>
            </div>
            <div class="fc-how__step">
                <div class="fc-how__num">4</div>
                <h3>Получение</h3>
                <p>Доставка по Новосибирску/Бердску или отправка по России.</p>
            </div>
        </div>

        <!-- Способы заказа -->
        <h2 class="fc-h2-center fc-animate">Способы оформления заказа</h2>

        <div class="fc-order-grid">

            <div class="fc-order-card fc-animate">
                <h3>💬 Через мессенджер</h3>
                <p>Быстрая консультация и оформление в Telegram или MAX.</p>
                <div class="fc-order-card__buttons">
                    <a href="https://t.me/flagcenter" target="_blank" class="fc-btn fc-btn--outline">Telegram</a>
                    <a href="https://max.ru/id5408257072_biz" target="_blank" class="fc-btn fc-btn--outline">MAX</a>
                </div>
            </div>

            <div class="fc-order-card">
    <h3>📞 По телефону</h3>
    <p>Моментальная консультация и оформление заказа по телефону.</p>
    <div class="fc-order-card__phones">
        <a href="tel:+73833251222" class="fc-btn fc-btn--primary">+7 (383) 325-12-22</a>
        <a href="tel:+79137191188" class="fc-btn fc-btn--primary">+7 (913) 719-11-88</a>
    </div>
</div>

            <div class="fc-order-card fc-animate">
                <h3>🛒 Через корзину</h3>
                <p>Добавьте товары в корзину и оформите заявку — менеджер свяжется для уточнения деталей и оплаты.</p>
                <a href="/shop/" class="fc-btn fc-btn--outline">Перейти в каталог</a>
            </div>

            <div class="fc-order-card fc-animate">
                <h3>📩 Через форму на сайте</h3>
                <p>Заполните короткую форму — менеджер сам свяжется в ближайшее время.</p>
                <a href="#fc-form" class="fc-btn fc-btn--outline">Оставить заявку</a>
            </div>

        </div>

    </div>
</section>

<!-- Форма -->
<section class="fc-section fc-form" id="fc-form">
    <div class="fc-container fc-container--narrow">
        <div class="fc-section-title fc-animate">
            <h2>Оставьте заявку</h2>
            <p class="fc-form__subtitle">Менеджер свяжется с вами в течение 15 минут</p>
        </div>
        <div class="fc-form__box fc-animate">
            <?php echo do_shortcode('[contact-form-7 id="091f6fa" title="Заявка"]'); ?>
        </div>
    </div>
</section>