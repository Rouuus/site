<?php
/**
 * Каталог товаров с боковой панелью категорий
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header( 'shop' );
?>

<div class="fc-shop-wrap">
    <div class="fc-container">

        <?php woocommerce_breadcrumb(); ?>

        <div class="fc-shop-layout">

            <!-- САЙДБАР -->
            <aside class="fc-shop-sidebar">
                <h3 class="fc-shop-sidebar__title">Категории</h3>

                <ul class="fc-cat-accordion">
                    <?php
                    $categories = get_terms([
                        'taxonomy'   => 'product_cat',
                        'hide_empty' => false,
                        'parent'     => 0,
                    ]);

                    $current_cat = is_product_category() ? get_queried_object_id() : 0;

                    foreach ( $categories as $cat ) :
                        $children = get_terms([
                            'taxonomy'   => 'product_cat',
                            'hide_empty' => false,
                            'parent'     => $cat->term_id,
                        ]);
                        $has_children = ! empty( $children ) && ! is_wp_error( $children );
                        $is_active    = ( $current_cat === $cat->term_id );
                        ?>
                        <li class="fc-cat-accordion__item <?php echo $has_children ? 'has-children' : ''; ?> <?php echo $is_active ? 'is-active' : ''; ?>">
                            <div class="fc-cat-accordion__head">
                                <a href="<?php echo esc_url( get_term_link( $cat ) ); ?>" class="fc-cat-accordion__link">
                                    <?php echo esc_html( $cat->name ); ?>
                                    <span class="fc-cat-accordion__count"><?php echo $cat->count; ?></span>
                                </a>
                                <?php if ( $has_children ) : ?>
                                    <button type="button" class="fc-cat-accordion__toggle" aria-label="Развернуть">+</button>
                                <?php endif; ?>
                            </div>

                            <?php if ( $has_children ) : ?>
                                <ul class="fc-cat-accordion__sub">
                                    <?php foreach ( $children as $child ) : ?>
                                        <li>
                                            <a href="<?php echo esc_url( get_term_link( $child ) ); ?>">
                                                <?php echo esc_html( $child->name ); ?>
                                                <span class="fc-cat-accordion__count"><?php echo $child->count; ?></span>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </aside>

            <!-- КОНТЕНТ -->
            <div class="fc-shop-content">
                <h1 class="fc-page-h1"><?php woocommerce_page_title(); ?></h1>

                <?php if ( woocommerce_product_loop() ) : ?>

                    <div class="fc-shop-toolbar">
                        <div class="fc-shop-toolbar__count">
                            <?php woocommerce_result_count(); ?>
                        </div>

                        <!-- Сортировка -->
                        <div class="fc-shop-toolbar__sort">
                            <?php woocommerce_catalog_ordering(); ?>
                        </div>
                    </div>

                    <?php woocommerce_product_loop_start(); ?>

                    <?php if ( wc_get_loop_prop( 'total' ) ) : ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php do_action( 'woocommerce_shop_loop' ); ?>
                            <?php wc_get_template_part( 'content', 'product' ); ?>
                        <?php endwhile; ?>
                    <?php endif; ?>

                    <?php woocommerce_product_loop_end(); ?>

                    <?php do_action( 'woocommerce_after_shop_loop' ); ?>

                    <!-- ОПИСАНИЕ КАТЕГОРИИ ВНИЗУ (ЕДИНСТВЕННЫЙ РАЗ) -->
                     <?php 
if ( is_product_category() ) {
    $term = get_queried_object();
    if ( ! empty( $term->description ) ) {
        // Разрешаем нужные HTML-теги и убираем авто-обертку в <p>
        $allowed_html = array(
            'h2' => array(), 'h3' => array(), 'h4' => array(),
            'ul' => array(), 'ol' => array(), 'li' => array(),
            'p' => array(), 'strong' => array(), 'em' => array(), 'br' => array(), 'a' => array('href' => array())
        );
        
        // Извлекаем "чистый" текст, убираем лишние <p> и <br>, которые мог наставить WP
        $clean_desc = wp_kses( $term->description, $allowed_html );
        
        echo '<div class="fc-custom-term-description fc-custom-term-description--bottom">' . $clean_desc . '</div>';
    }
}
?>

                <?php else : ?>
                    <?php do_action( 'woocommerce_no_products_found' ); ?>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<?php get_footer( 'shop' ); ?>