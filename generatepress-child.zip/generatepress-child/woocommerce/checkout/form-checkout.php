<?php
/**
 * Checkout Form — фирменный шаблон Flag Center
 *
 * @package WooCommerce\Templates
 * @version 8.3.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_checkout_form', $checkout );

// Если корзина пуста — WooCommerce сам покажет уведомление
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
    echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'Вы должны войти в систему, чтобы оформить заказ.', 'woocommerce' ) ) );
    return;
}
?>

<div class="fc-checkout-wrap">
    <div class="fc-container">

        <form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

            <div class="fc-checkout-layout">

                <!-- ЛЕВАЯ КОЛОНКА: ФОРМА -->
                <div class="fc-checkout-main">

                    <?php if ( $checkout->get_checkout_fields() ) : ?>

                        <?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

                        <div class="fc-checkout-section">
    <?php do_action( 'woocommerce_checkout_billing' ); ?>
</div>

                        <?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

                    <?php endif; ?>

                </div>

                <!-- ПРАВАЯ КОЛОНКА: ЗАКАЗ -->
                <aside class="fc-checkout-side">

                    <div class="fc-checkout-order">

                        <h2 class="fc-checkout-order__title">Ваш заказ</h2>

                        <?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>

                        <div id="order_review" class="woocommerce-checkout-review-order">
                            <?php do_action( 'woocommerce_checkout_order_review' ); ?>
                        </div>

                        <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

                    </div>

                </aside>

            </div>

        </form>

        <?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>

    </div>
</div>