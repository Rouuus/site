<?php
/**
 * Checkout coupon form — русифицированный
 *
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) {
    return;
}

?>
<div class="woocommerce-form-coupon-toggle">
    <?php wc_print_notice( apply_filters( 'woocommerce_checkout_coupon_message', 'Есть купон?' . ' <a href="#" class="showcoupon">Нажмите здесь, чтобы ввести код</a>' ), 'notice' ); ?>
</div>

<form class="checkout_coupon woocommerce-form-coupon" method="post" style="display:none">

    <p>Введите код купона, если он у вас есть.</p>

    <p class="form-row form-row-first">
        <input type="text" name="coupon_code" class="input-text" placeholder="Код купона" id="coupon_code" value="" />
    </p>

    <p class="form-row form-row-last">
        <button type="submit" class="button" name="apply_coupon" value="Применить купон">Применить купон</button>
    </p>

    <div class="clear"></div>
</form>