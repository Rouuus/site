<?php
/**
 * Thankyou page — фирменный шаблон Flag Center
 *
 * @package WooCommerce\Templates
 * @version 8.1.0
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="fc-thankyou-wrap">
    <div class="fc-container">

        <?php if ( $order ) : ?>

            <?php if ( $order->has_status( 'failed' ) ) : ?>

                <div class="fc-thankyou fc-thankyou--failed">
                    <div class="fc-thankyou__icon">✕</div>
                    <h1 class="fc-thankyou__title">Оплата не прошла</h1>
                    <p class="fc-thankyou__text">
                        К сожалению, платёж не был обработан. Попробуйте ещё раз или свяжитесь с нами.
                    </p>
                    <div class="fc-thankyou__actions">
                        <a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="fc-btn fc-btn--primary">Попробовать снова</a>
                    </div>
                </div>

            <?php else : ?>

                <div class="fc-thankyou">

                    <!-- Галочка + заголовок -->
                    <div class="fc-thankyou__hero">
                        <div class="fc-thankyou__icon">✓</div>
                        <h1 class="fc-thankyou__title">Спасибо за заказ!</h1>
                        <p class="fc-thankyou__text">
                            Ваш заказ <strong>№<?php echo esc_html( $order->get_order_number() ); ?></strong> принят.
                            Менеджер свяжется с вами в течение <strong>15 минут</strong> в рабочее время
                            для подтверждения деталей и способа оплаты.
                        </p>
                    </div>

                    <!-- Что дальше -->
                    <div class="fc-thankyou__steps">
                        <div class="fc-thankyou__step">
                            <div class="fc-thankyou__step-num">1</div>
                            <div>
                                <strong>Менеджер свяжется</strong>
                                <p>Уточнит детали заказа, макет и способ оплаты.</p>
                            </div>
                        </div>
                        <div class="fc-thankyou__step">
                            <div class="fc-thankyou__step-num">2</div>
                            <div>
                                <strong>Согласуем макет и сроки</strong>
                                <p>Пришлём макет на утверждение и назовём точную дату готовности.</p>
                            </div>
                        </div>
                        <div class="fc-thankyou__step">
                            <div class="fc-thankyou__step-num">3</div>
                            <div>
                                <strong>Отшиваем и доставляем</strong>
                                <p>Изготовим заказ и отправим удобным для вас способом.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Детали заказа -->
                    <div class="fc-thankyou__details">
                        <h2>Детали заказа</h2>

                        <table class="fc-thankyou__table">
                            <thead>
                                <tr>
                                    <th>Товар</th>
                                    <th>Сумма</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ( $order->get_items() as $item_id => $item ) :
                                    $product = $item->get_product();
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo esc_html( $item->get_name() ); ?>
                                            <?php if ( $item->get_quantity() > 1 ) : ?>
                                                <span class="fc-thankyou__qty">× <?php echo esc_html( $item->get_quantity() ); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Итого</th>
                                    <td class="fc-thankyou__total"><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
                                </tr>
                            </tfoot>
                        </table>

                        <?php if ( $order->get_customer_note() ) : ?>
                            <div class="fc-thankyou__note">
                                <strong>Ваш комментарий:</strong>
                                <p><?php echo wp_kses_post( nl2br( $order->get_customer_note() ) ); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Срочная связь -->
                    <div class="fc-thankyou__contacts">
                        <h3>Нужно срочно?</h3>
                        <p>Свяжитесь с нами напрямую:</p>
                        <div class="fc-thankyou__buttons">
                            <a href="tel:+79137191188" class="fc-btn fc-btn--primary">+7 913 719-11-88</a>
                            <a href="https://max.ru/id5408257072_biz" target="_blank" class="fc-btn fc-btn--outline">MAX</a>
                            <a href="https://t.me/flagcenter" target="_blank" class="fc-btn fc-btn--outline">Telegram</a>
                        </div>
                    </div>

                    <!-- Возврат в каталог -->
                    <div class="fc-thankyou__back">
                        <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="fc-btn fc-btn--outline">
                            ← Вернуться в каталог
                        </a>
                    </div>

                </div>

            <?php endif; ?>

        <?php else : ?>

            <div class="fc-thankyou">
                <div class="fc-thankyou__hero">
                    <div class="fc-thankyou__icon">✓</div>
                    <h1 class="fc-thankyou__title">Спасибо за заказ!</h1>
                    <p class="fc-thankyou__text">Ваш заказ принят. Мы свяжемся с вами в ближайшее время.</p>
                </div>
                <div class="fc-thankyou__back">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="fc-btn fc-btn--outline">← На главную</a>
                </div>
            </div>

        <?php endif; ?>

    </div>
</div>