<?php
/**
 * Result Count — русифицированный
 *
 * @package WooCommerce\Templates
 * @version 3.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<p class="woocommerce-result-count">
    <?php
    if ( 1 === intval( $total ) ) {
        echo 'Показан 1 товар';
    } elseif ( $total <= $per_page || -1 === $per_page ) {
        printf( 'Показано все %d товаров', $total );
    } else {
        $first = ( $per_page * $current ) - $per_page + 1;
        $last  = min( $total, $per_page * $current );
        printf( 'Показано %1$d–%2$d из %3$d товаров', $first, $last, $total );
    }
    ?>
</p>