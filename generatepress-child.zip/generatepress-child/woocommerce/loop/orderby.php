<?php
/**
 * Orderby — русифицированный
 *
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$options = [
    'menu_order' => 'По умолчанию',
    'popularity' => 'По популярности',
    'rating'     => 'По рейтингу',
    'date'       => 'Сначала новые',
    'price'      => 'Цена: по возрастанию',
    'price-desc' => 'Цена: по убыванию',
];
?>

<form class="woocommerce-ordering" method="get">
    <select name="orderby" class="orderby" aria-label="Сортировка товаров">
        <?php foreach ( $options as $id => $label ) : ?>
            <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>>
                <?php echo esc_html( $label ); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <input type="hidden" name="paged" value="1" />
    <?php wc_query_string_form_fields( null, [ 'orderby', 'paged' ], '', true ); ?>
</form>