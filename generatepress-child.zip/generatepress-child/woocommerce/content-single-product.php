<?php
/**
 * Карточка товара — фирменный стиль Flag Center
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $product;

do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
    echo get_the_password_form();
    return;
}
?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'fc-product', $product ); ?>>

    <div class="fc-product__top">

        <!-- ГАЛЕРЕЯ (30%) -->
        <div class="fc-product__gallery">
            <?php
            $attachment_ids = $product->get_gallery_image_ids();
            $main_image_id  = $product->get_image_id();
            ?>
            <div class="fc-gallery">
                <div class="fc-gallery__main">
                    <?php echo wp_get_attachment_image( $main_image_id, 'large', false, [ 'class' => 'fc-gallery__main-img' ] ); ?>
                </div>

                <?php if ( ! empty( $attachment_ids ) ) : ?>
                    <div class="fc-gallery__thumbs">
                        <div class="fc-gallery__thumb is-active" data-src="<?php echo esc_url( wp_get_attachment_image_url( $main_image_id, 'large' ) ); ?>">
                            <?php echo wp_get_attachment_image( $main_image_id, 'thumbnail' ); ?>
                        </div>
                        <?php foreach ( $attachment_ids as $id ) : ?>
                            <div class="fc-gallery__thumb" data-src="<?php echo esc_url( wp_get_attachment_image_url( $id, 'large' ) ); ?>">
                                <?php echo wp_get_attachment_image( $id, 'thumbnail' ); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ИНФОРМАЦИЯ (70%) -->
        <div class="fc-product__info">

            <h1 class="fc-product__title"><?php the_title(); ?></h1>

            <?php if ( $product->get_price_html() ) : ?>
                <div class="fc-product__price"><?php echo $product->get_price_html(); ?></div>
            <?php endif; ?>

            <?php if ( $product->get_short_description() ) : ?>
                <div class="fc-product__excerpt">
                    <?php echo apply_filters( 'woocommerce_short_description', $product->get_short_description() ); ?>
                </div>
            <?php endif; ?>

            <!-- Срок изготовления -->
            <div class="fc-product__term">
                <span class="fc-product__term-icon">⏱</span>
                <div>
                    <strong>Срок изготовления:</strong> от 1 дня
                    <span class="fc-product__term-note">Точный срок менеджер подтвердит после согласования макета</span>
                </div>
            </div>

            <!-- Форма добавления в корзину -->
            <div class="fc-product__cart">
                <?php woocommerce_template_single_add_to_cart(); ?>
            </div>

            <!-- Кнопки связи -->
            <div class="fc-product__contacts">
    <a href="https://max.ru/id5408257072_biz" target="_blank" class="fc-btn fc-btn--outline">Уточнить в MAX</a>
    <a href="https://t.me/flagcenter" target="_blank" class="fc-btn fc-btn--outline">Telegram</a>
</div>

            <!-- Мета (артикул, категории) -->
            <?php woocommerce_template_single_meta(); ?>

        </div>
    </div>

    <!-- ВКЛАДКИ -->
    <div class="fc-product__tabs">
        <div class="fc-tabs">
           <div class="fc-tabs__nav">
    <button class="fc-tabs__btn is-active" data-tab="description">Описание</button>
    <button class="fc-tabs__btn" data-tab="materials">Из чего шьём</button>
    <button class="fc-tabs__btn" data-tab="requirements">Требования к макету</button>
</div>

            <div class="fc-tabs__panels">

                <!-- Вкладка 1: Материалы -->
               <div class="fc-tabs__panel" data-panel="materials">
    <h2>Из чего мы шьём</h2>
    <p>Мы подбираем ткань под задачу. Ниже — стандартные материалы для основных видов продукции. Если нужен другой материал — уточните у менеджера.</p>

    <table class="fc-materials-table">
        <thead>
            <tr>
                <th>Продукция</th>
                <th>Материалы</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Флаги</td>
                <td>Флажный шёлк, флажная сетка, декоративное полотно, блэкаут</td>
            </tr>
            <tr>
                <td>Спортивная форма</td>
                <td>Ложная сетка лайт, ника, пике, интерлок, бифлекс</td>
            </tr>
            <tr>
                <td>Рекламный текстиль</td>
                <td>Габардин, оксфорд, флис, атлас, сатен, дюспо, таффета, шёлк армани, шифон, шармус люкс, полиоксфорд, сетен, сэндвич</td>
            </tr>
            <tr>
                <td>Одежда</td>
                <td>Ложная сетка лайт, таффета курточная, дюспо, футер полиэстер с хлопком, футер 3-нитка (петля), футер 3-нитка (начёс), кулирка с лайкрой</td>
            </tr>
            <tr>
                <td>Вымпелы</td>
                <td>Атлас</td>
            </tr>
        </tbody>
    </table>

    <p class="fc-materials-note">
        <strong>Не нашли свой материал?</strong> Мы работаем с любыми тканями на заказ — пришлите образец или опишите задачу, подберём оптимальный вариант.
    </p>
</div>

                <!-- Вкладка 2: Требования к макету -->
                <div class="fc-tabs__panel" data-panel="requirements">
                    <h2>Как подготовить макет для печати на ткани</h2>
                    <p class="fc-req-lead">Правильная подготовка — залог отличного качества и предсказуемого результата.</p>

                    <h3>Процесс печати на ткани</h3>
                    <p>Мы используем два вида оборудования: <strong>сублимационную печать</strong> и <strong>DTF-печать</strong>. Технология подбирается под ткань, тираж и задачу.</p>

                    <div class="fc-warning">
                        <h4>⚠️ Важное предупреждение об усадке ткани</h4>
                        <p><strong>Внимание!</strong> Допустимая усадка ткани при термопереносе может составлять <strong>2–5%</strong> от размера готового изделия.</p>
                        <p>Учитывайте этот фактор при разработке дизайна и планировании размеров.</p>
                        <p>Рекомендуется закладывать запас по краям макета для компенсации возможной усадки материала в процессе термической обработки.</p>
                    </div>

                    <h3>Технические требования к макетам</h3>

                    <div class="fc-req-grid">
                        <div class="fc-req-card">
                            <h4>Требования к векторным макетам</h4>
                            <ul>
                                <li>Масштаб строго <strong>1:1</strong></li>
                                <li>Цветовая схема — только <strong>CMYK</strong></li>
                                <li>Чёрный цвет: <strong>C65 M65 Y65 K95</strong></li>
                                <li>Все шрифты в кривые или приложить файлы шрифтов</li>
                                <li>Минимальная толщина линий — <strong>0,3 мм</strong></li>
                                <li>Тени, прозрачность и эффекты — в растре</li>
                                <li>Форматы: CDR (до 20), AI (до CC), PDF, EPS</li>
                            </ul>
                            <p class="fc-req-important">Удалите все вспомогательные элементы, направляющие и лишние слои перед отправкой!</p>
                        </div>

                        <div class="fc-req-card">
                            <h4>Требования к растровым макетам</h4>
                            <ul>
                                <li>Размер в масштабе 1:1, режим CMYK</li>
                                <li>Шрифты — растрированы или отдельные файлы</li>
                                <li>Все эффекты (тени, прозрачность) — в растре</li>
                                <li>Разрешение:
                                    <ul>
                                        <li>72 dpi — большие флаги</li>
                                        <li>150 dpi — до 15×22 см</li>
                                    </ul>
                                </li>
                                <li>Двусторонняя печать — два отдельных файла</li>
                                <li>Форматы: TIFF, PSD, JPEG, PNG</li>
                            </ul>
                        </div>
                    </div>

                    <div class="fc-info">
                        <h4>Важно понимать:</h4>
                        <ul>
                            <li>Цвет на экране не совпадает с реальной печатью</li>
                            <li>Один и тот же цвет на разных тканях выглядит по-разному</li>
                            <li>Допустимы отклонения на 1–2 тона — это технологическая норма</li>
                            <li>Критичные оттенки — только после бесплатной цветопробы</li>
                        </ul>
                    </div>

                    <h3>Допустимые технологические особенности</h3>
                    <p>Небольшие крапинки и микровключения чернил при струйной печати на текстиле — <strong>не брак</strong> (согласно ГОСТ 31131-98).</p>
                    <p>Современное оборудование максимально снижает такие проявления, но полностью исключить их невозможно из-за природы ткани и чернил.</p>
                    <p><strong>Соблюдение всех указанных требований гарантирует максимально качественный и предсказуемый результат печати.</strong></p>
                </div>

                <!-- Вкладка 3: Описание -->
                <div class="fc-tabs__panel is-active" data-panel="description">
                    <?php the_content(); ?>
                </div>

            </div>
        </div>
    </div>

    <!-- Похожие товары -->
    <?php woocommerce_output_related_products(); ?>

</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>