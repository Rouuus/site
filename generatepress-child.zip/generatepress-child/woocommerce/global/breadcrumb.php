<?php
/**
 * Breadcrumb — русифицированный вывод
 *
 * @package WooCommerce\Templates
 * @version 2.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! empty( $breadcrumb ) ) {

    echo $wrap_before;

    foreach ( $breadcrumb as $key => $crumb ) {

        echo $before;

        // Первый элемент — всегда "Главная"
        if ( ! empty( $crumb[1] ) && sizeof( $breadcrumb ) !== $key + 1 ) {
            $label = ( 0 === $key ) ? 'Главная' : $crumb[0];
            echo '<a href="' . esc_url( $crumb[1] ) . '">' . esc_html( $label ) . '</a>';
        } else {
            // Последний элемент — текущая страница, без ссылки
            echo esc_html( $crumb[0] );
        }

        echo $after;

        // Разделитель
        if ( sizeof( $breadcrumb ) !== $key + 1 ) {
            echo $delimiter;
        }
    }

    echo $wrap_after;
}