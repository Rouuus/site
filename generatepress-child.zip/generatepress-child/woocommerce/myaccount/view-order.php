<?php
/**
 * View Order — фирменный шаблон Flag Center
 *
 * @package WooCommerce\Templates
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

$notes = $order->get_customer_order_notes();
$status = $order->get_status();
?>

<div class="fc-order-view">

    <!-- Шапка -->
    <div class="fc-order-view__head">
        <div class="fc-order-view__num">
            <h2>Заказ №<?php echo esc_html( $order->get_order_number() ); ?></h2>
            <p class="fc-order-view__date">
                от <?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?>
            </p>
        </div>
        <div class="fc-order-view__status">
            <span class="fc-status fc-status-<?php echo esc_attr( $status ); ?>">
                <?php echo esc_html( wc_get_order_status_name( $status ) ); ?>
            </span>
        </div>
    </div>

    <!-- Прогресс -->
    <?php
    $steps = [
        'pending'    => 'Принят',
        'processing' => 'В работе',
        'on-hold'    => 'Ожидает',
        'shipped'    => 'Отправлен',
        'completed'  => 'Выполнен',
    ];

    $status_order = [ 'pending', 'processing', 'shipped', 'completed' ];
    $current_idx  = array_search( $status, $status_order, true );
    if ( $current_idx === false ) {
        $current_idx = 0;
    }
    ?>

    <div class="fc-order-progress">
        <?php
        $progress_steps = [
            'pending'    => 'Принят',
            'processing' => 'В работе',
            'shipped'    => 'Отправлен',
            'completed'  => 'Выполнен',
        ];
        $i = 0;
        foreach ( $progress_steps as $key => $label ) :
            $is_done    = $i <= $current_idx;
            $is_current = $i === $current_idx;
            ?>
            <div class="fc-order-progress__step <?php echo $is_done ? 'is-done' : ''; ?> <?php echo $is_current ? 'is-current' : ''; ?>">
                <div class="fc-order-progress__dot"><?php echo $is_done ? '✓' : $i + 1; ?></div>
                <div class="fc-order-progress__label"><?php echo esc_html( $label ); ?></div>
            </div>
            <?php
            $i++;
        endforeach;
        ?>
    </div>

    <!-- Детали -->
    <div class="fc-order-view__details">

        <h3>Состав заказа</h3>

        <table class="fc-order-view__table">
            <thead>
                <tr>
                    <th>Товар</th>
                    <th>Количество</th>
                    <th>Сумма</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $order->get_items() as $item_id => $item ) : ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html( $item->get_name() ); ?></strong>
                            <?php
                            $meta = wc_display_item_meta( $item, [ 'echo' => false ] );
                            if ( $meta ) {
                                echo '<div class="fc-order-view__meta">' . $meta . '</div>';
                            }
                            ?>
                        </td>
                        <td><?php echo esc_html( $item->get_quantity() ); ?></td>
                        <td><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <?php foreach ( $order->get_order_item_totals() as $key => $total ) : ?>
                    <tr class="<?php echo esc_attr( $key ); ?>">
                        <th colspan="2"><?php echo esc_html( $total['label'] ); ?></th>
                        <td><?php echo wp_kses_post( $total['value'] ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tfoot>
        </table>

    </div>

    <!-- Адреса -->
    <div class="fc-order-view__addresses">

        <div class="fc-order-view__address">
            <h4>Доставка</h4>
            <address>
                <?php echo wp_kses_post( $order->get_formatted_shipping_address() ?: '—' ); ?>
            </address>
        </div>

        <div class="fc-order-view__address">
            <h4>Оплата</h4>
            <p><?php echo esc_html( $order->get_payment_method_title() ?: '—' ); ?></p>
            <?php if ( $order->get_formatted_billing_address() ) : ?>
                <address>
                    <?php echo wp_kses_post( $order->get_formatted_billing_address() ); ?>
                </address>
            <?php endif; ?>
        </div>

    </div>

    <!-- Кнопки -->
    <div class="fc-order-view__actions">
        <?php foreach ( wc_get_account_orders_actions( $order ) as $key => $action ) : ?>
            <a href="<?php echo esc_url( $action['url'] ); ?>" class="fc-btn fc-btn--outline fc-btn--sm <?php echo esc_attr( $key ); ?>">
                <?php echo esc_html( $action['name'] ); ?>
            </a>
        <?php endforeach; ?>

        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>" class="fc-btn fc-btn--outline fc-btn--sm">
            ← Все заказы
        </a>
    </div>

</div>