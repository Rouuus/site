<?php
/**
 * My Account page — фирменный контейнер
 *
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

defined( 'ABSPATH' ) || exit;

wc_print_notices();
?>

<div class="fc-account-wrap">
    <div class="fc-container">
        <h1 class="fc-account-title">Личный кабинет</h1>
        <?php do_action( 'woocommerce_account_content' ); ?>
    </div>
</div>