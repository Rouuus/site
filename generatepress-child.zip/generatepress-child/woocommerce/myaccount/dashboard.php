<?php
/**
 * My Account Dashboard — фирменный шаблон Flag Center
 *
 * @package WooCommerce\Templates
 * @version 4.4.0
 */

defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
$first_name   = $current_user->first_name ?: $current_user->display_name;

// Последние 3 заказа
$recent_orders = wc_get_orders([
    'customer' => get_current_user_id(),
    'limit'    => 3,
    'orderby'  => 'date',
    'order'    => 'DESC',
]);
?>

<div class="fc-account-dashboard">
<div class="fc-account-topbar">
    <div class="fc-account-topbar__user">
        <strong><?php echo esc_html( $first_name ); ?></strong>
        <span><?php echo esc_html( $current_user->user_email ); ?></span>
    </div>
    <a href="<?php echo esc_url( wc_logout_url() ); ?>" class="fc-account-logout">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Выйти
    </a>
</div>
    <!-- Приветствие -->
    <div class="fc-account-hello">
        <h2>Здравствуйте, <?php echo esc_html( $first_name ); ?>!</h2>
        <p>Здесь вы можете отслеживать свои заказы, менять адрес доставки и редактировать данные аккаунта.</p>
    </div>

    <!-- Быстрые ссылки -->
    <div class="fc-account-quick">

        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>" class="fc-account-quick__item">
            <div class="fc-account-quick__icon">📦</div>
            <div class="fc-account-quick__label">Мои заказы</div>
            <div class="fc-account-quick__hint">История и статус</div>
        </a>

        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'edit-address' ) ); ?>" class="fc-account-quick__item">
            <div class="fc-account-quick__icon">📍</div>
            <div class="fc-account-quick__label">Адреса</div>
            <div class="fc-account-quick__hint">Доставка и получатель</div>
        </a>

        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'edit-account' ) ); ?>" class="fc-account-quick__item">
            <div class="fc-account-quick__icon">👤</div>
            <div class="fc-account-quick__label">Мои данные</div>
            <div class="fc-account-quick__hint">Имя, email, пароль</div>
        </a>

        <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="fc-account-quick__item">
            <div class="fc-account-quick__icon">🛒</div>
            <div class="fc-account-quick__label">Каталог</div>
            <div class="fc-account-quick__hint">Продолжить покупки</div>
        </a>

    </div>

    <!-- Последние заказы -->
    <?php if ( ! empty( $recent_orders ) ) : ?>
        <div class="fc-account-recent">
            <div class="fc-account-recent__head">
                <h3>Последние заказы</h3>
                <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>" class="fc-account-recent__all">
                    Все заказы →
                </a>
            </div>

            <div class="fc-account-recent__list">
                <?php foreach ( $recent_orders as $order ) :
    // Пропускаем черновики
    if ( 'draft' === $order->get_status() ) {
        continue;
    }
    $status       = $order->get_status();
    $status_label = wc_get_order_status_name( $status );
    ?>
                    <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="fc-account-order-card">
                        <div class="fc-account-order-card__head">
                            <span class="fc-account-order-card__num">
                                Заказ №<?php echo esc_html( $order->get_order_number() ); ?>
                            </span>
                            <span class="fc-account-order-card__status fc-status-<?php echo esc_attr( $status ); ?>">
                                <?php echo esc_html( $status_label ); ?>
                            </span>
                        </div>
                        <div class="fc-account-order-card__meta">
                            <span><?php echo esc_html( wc_format_datetime( $order->get_date_created(), 'd.m.Y' ) ); ?></span>
                            <span class="fc-account-order-card__total">
                                <?php echo wp_kses_post( $order->get_formatted_order_total() ); ?>
                            </span>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php else : ?>
        <div class="fc-account-empty">
            <p>У вас пока нет заказов.</p>
            <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="fc-btn fc-btn--primary">Перейти в каталог</a>
        </div>
    <?php endif; ?>

</div>