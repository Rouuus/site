<?php
/**
 * My Account Orders — фирменный шаблон Flag Center
 *
 * @package WooCommerce\Templates
 * @version 7.8.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_account_orders', $has_orders ); ?>

<?php if ( $has_orders ) : ?>

    <div class="fc-orders-list">

        <?php
        foreach ( $customer_orders->orders as $customer_order ) {
    $order = wc_get_order( $customer_order );

    // Пропускаем черновики
    if ( 'draft' === $order->get_status() ) {
        continue;
    }
            $customer_orders = wc_get_orders([
    'customer' => get_current_user_id(),
    'status'   => array_diff( array_keys( wc_get_order_statuses() ), [ 'wc-draft' ] ),
    'paginate' => true,
    'page'     => max( 1, get_query_var( 'paged' ) ),
    'limit'    => 10,
]);
            ?>
            <div class="fc-order-item">

                <div class="fc-order-item__head">
                    <div class="fc-order-item__num">
                        <span class="fc-order-item__label">Заказ</span>
                        <strong>№<?php echo esc_html( $order->get_order_number() ); ?></strong>
                    </div>
                    <div class="fc-order-item__date">
                        <span class="fc-order-item__label">Дата</span>
                        <strong><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></strong>
                    </div>
                    <div class="fc-order-item__status">
                        <span class="fc-order-item__label">Статус</span>
                        <span class="fc-status fc-status-<?php echo esc_attr( $status ); ?>">
                            <?php echo esc_html( wc_get_order_status_name( $status ) ); ?>
                        </span>
                    </div>
                    <div class="fc-order-item__total">
                        <span class="fc-order-item__label">Сумма</span>
                        <strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong>
                    </div>
                </div>

                <div class="fc-order-item__body">
                    <div class="fc-order-item__products">
                        <?php
                        $items = $order->get_items();
                        $names = [];
                        foreach ( $items as $item ) {
                            $names[] = $item->get_name() . ( $item->get_quantity() > 1 ? ' × ' . $item->get_quantity() : '' );
                        }
                        echo esc_html( implode( ', ', $names ) );
                        ?>
                    </div>
                    <div class="fc-order-item__actions">
                        <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="fc-btn fc-btn--outline fc-btn--sm">
                            Подробнее
                        </a>
                        <?php if ( in_array( $status, [ 'pending', 'on-hold' ], true ) ) : ?>
                            <a href="<?php echo esc_url( $order->get_cancel_order_url( wc_get_page_permalink( 'myaccount' ) ) ); ?>" class="fc-order-item__cancel" onclick="return confirm('Отменить заказ?');">
                                Отменить
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        <?php } ?>

    </div>

    <?php do_action( 'woocommerce_before_account_orders_pagination' ); ?>

    <?php if ( 1 < $customer_orders->max_num_pages ) : ?>
        <nav class="fc-orders-pagination">
            <?php
            echo paginate_links([
                'base'      => esc_url_raw( str_replace( 999999999, '%#%', remove_query_arg( 'add-to-cart', get_pagenum_link( 999999999, false ) ) ) ),
                'format'    => '?paged=%#%',
                'current'   => max( 1, get_query_var( 'paged' ) ),
                'total'     => $customer_orders->max_num_pages,
                'prev_text' => '←',
                'next_text' => '→',
                'type'      => 'list',
            ]);
            ?>
        </nav>
    <?php endif; ?>

<?php else : ?>

    <div class="fc-account-empty">
        <div class="fc-account-empty__icon">📦</div>
        <h3>У вас пока нет заказов</h3>
        <p>Как только вы оформите первый заказ, он появится здесь.</p>
        <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="fc-btn fc-btn--primary">
            Перейти в каталог
        </a>
    </div>

<?php endif; ?>

<?php do_action( 'woocommerce_after_account_orders', $has_orders ); ?>